<?php 

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class LapPelanggan extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		if($this->session->userdata('level') == ""){
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				  <strong>Anda Belum Login!</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
				redirect('welcome');

		}
	}

	public function index()
	{
		$data['title'] = "Laporan Data Pelanggan";
		$where 	= "";
		if((isset($_GET['tglawal']) && $_GET['tglawal']!='') && (isset($_GET['tglakhir']) && $_GET['tglakhir']!='')){
			$tglawal = $_GET['tglawal'];
			$tglakhir = $_GET['tglakhir'];
			if (!empty($where)) {
				$where 	.= " AND (tgl_daftar BETWEEN '$tglawal' and '$tglakhir')";
			}else {
				$where 	= "(tgl_daftar BETWEEN '$tglawal' and '$tglakhir')";
			}
		}else {
			$hariini = date('Y-m-d');
			if (!empty($where)) {
				$where 	.= " AND tgl_daftar = '$hariini'";
			}else {
				$where 	= " tgl_daftar = '$hariini'";
			}
		}
		if((isset($_GET['fjfas']) && $_GET['fjfas']!='')){
			$jenis = $_GET['fjfas'];
			if (!empty($where)) {
				$where 	.= " AND status='$jenis'";
			}
		}
		if((isset($_GET['fpoli']) && $_GET['fpoli']!='')){
			$poli = $_GET['fpoli'];
			if (!empty($where)) {
				$where 	.= " AND tb_pelanggan.id_layanan='$poli'";
			}
		}



		$data['tunggu']	= $this->db->query("SELECT * FROM tb_pelanggan
			WHERE status='2'
			ORDER BY tgl_daftar DESC")->result();
		$data['layanan'] = $this->clinicModel->get_data('tb_layanan')->result();
		$data['datapelanggan'] = $this->db->query("SELECT tb_pelanggan.*, tb_layanan.layanan as nlayanan
			FROM tb_pelanggan
			INNER JOIN tb_layanan ON tb_pelanggan.id_layanan=tb_layanan.id_layanan
			WHERE $where ORDER BY tb_pelanggan.tgl_daftar DESC")->result();

		$data['datapelanggan'] = $this->db->query("SELECT tb_pelanggan.*, tb_daerah.daerah as ndaerah
			FROM tb_pelanggan
			INNER JOIN tb_daerah ON tb_pelanggan.id_daerah=tb_daerah.id_daerah
			WHERE $where ORDER BY tb_pelanggan.tgl_daftar DESC")->result();

		if($this->session->userdata('level') =='1') {
			$this->load->view('templates_admin/header',$data);
			$this->load->view('templates_admin/sidebar',$data);
			$this->load->view('laporan/lapPelanggan',$data);
			$this->load->view('templates_admin/footer');
		}elseif($this->session->userdata('level') =='2') {
			$this->load->view('templates_pimpinan/header',$data);
			$this->load->view('templates_pimpinan/sidebar',$data);
			$this->load->view('laporan/lapPelanggan',$data);
			$this->load->view('templates_pimpinan/footer');
		}elseif($this->session->userdata('level') =='3') {
			$this->load->view('templates_regist/header',$data);
			$this->load->view('templates_regist/sidebar',$data);
			$this->load->view('laporan/lapPelanggan',$data);
			$this->load->view('templates_regist/footer');
		}
		
	}

	public function export(){
    

    $thn = date('d-m-Y');
		$where1 		= "";
		$tgla1 		= $this->input->post('tgla1');
		$tgln1 		= $this->input->post('tgln1');
		$faskes1 	= $this->input->post('faskes1');
		$poli1 		= $this->input->post('poli1');
		if (!empty($faskes1)) {
			$where1 	.= " AND status='$faskes1'";
		}
		if (!empty($poli1)) {
			$where1 	.= " AND tb_pelanggan.id_layanan='$poli1'";
		}

       
        // title dari pdf
        $data['title'] = "Laporan Data Pelanggan";
        $data['tgla'] = $this->input->post('tgla1');
        $data['tgln'] = $this->input->post('tgln1');
        $data['faskes'] = $this->input->post('faskes1');
        $data['poli'] = $this->input->post('poli1');
        $data['datapelanggan'] = $this->db->query("SELECT tb_pelanggan.*, tb_layanan.layanan as nlayanan
			FROM tb_pelanggan
			INNER JOIN tb_layanan ON tb_pelanggan.id_layanan=tb_layanan.id_layanan
			WHERE (date(tgl_daftar) BETWEEN '$tgla1' and '$tgln1') $where1
			ORDER BY tb_pelanggan.id_pelanggan ASC ")->result();
        // Skrip berikut ini adalah skrip yang bertugas untuk meng-export data tadi ke excel
    header("Content-type: application/vnd-ms-excel");
    header("Content-Disposition: attachment; filename=Data_Pelanggan-$thn.xls");
    
    $this->load->view('laporan/excelPelanggan',$data);
   
  }

	public function printPelanggan()
	{
		$thn = date('Y-m-d');
		$where 		= "";
		$tgla 		= $this->input->post('tgla');
		$tgln 		= $this->input->post('tgln');
		$faskes 	= $this->input->post('faskes');
		$poli 		= $this->input->post('poli');
		if (!empty($faskes)) {
			$where 	.= " AND status='$faskes'";
		}
		if (!empty($poli)) {
			$where 	.= " AND tb_pelanggan.id_layanan='$poli'";
		}
		// panggil library yang kita buat sebelumnya yang bernama pdfgenerator
        $this->load->library('pdfgenerator');
        
        // title dari pdf
        $this->data['title'] = "Laporan Pelanggan Meldina Network";
        $this->data['tgla'] = $this->input->post('tgla');
        $this->data['tgln'] = $this->input->post('tgln');
        $this->data['faskes'] = $this->input->post('faskes');
        $this->data['poli'] = $this->input->post('poli');
        $this->data['datapelanggan'] = $this->db->query("SELECT tb_pelanggan.*, tb_layanan.layanan as nlayanan
			FROM tb_pelanggan
			INNER JOIN tb_layanan ON tb_pelanggan.id_layanan=tb_layanan.id_layanan
			WHERE (date(tgl_daftar) BETWEEN '$tgla' and '$tgln') $where
			ORDER BY tb_pelanggan.id_pelanggan ASC ")->result();
        
        // filename dari pdf ketika didownload
        $file_pdf = 'Laporan_data_pengunjung-'.$thn;
        // setting paper
        $paper = 'F4';
        //orientasi paper potrait / landscape
        $orientation = "landscape";
        
		$html = $this->load->view('laporan/cetakDataPelanggan',$this->data,true);	    
        
        // run dompdf
        $this->pdfgenerator->generate($html, $file_pdf,$paper,$orientation);


	}

	




}

 ?>