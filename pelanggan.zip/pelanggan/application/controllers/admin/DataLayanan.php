<?php 

/**
 * 
 */
class DataLayanan extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		if($this->session->userdata('level') !='1'){
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				  <strong>Anda Belum Login!</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
				redirect('welcome');

		}
		$this->load->model("clinicModel");
	}

	public function index()
	{
		
		$data['title'] = "Data Layanan";
		$data['layanan'] = $this->clinicModel->get_data('tb_layanan')->result();
		$data['kodeunik'] = $this->clinicModel->no_layanan();
		$data['tunggu']	= $this->db->query("SELECT * FROM tb_pelanggan
			WHERE status='2'
			ORDER BY tgl_daftar DESC")->result();
		$this->load->view('templates_admin/header',$data);
		$this->load->view('templates_admin/sidebar',$data);
		$this->load->view('admin/dataLayanan',$data);
		$this->load->view('templates_admin/footer');
	}

	public function tambahDataAksi()
	{
		$this->_rules();
		if ($this->form_validation->run() == FALSE) {
			$this->tambahData();
		}else{
			$id_layanan 	= $this->input->post('id_layanan');
			$layanan 		= $this->input->post('layanan');
			$tarif 			= $this->input->post('tarif');

			$data= array(

				'id_layanan'	=> $id_layanan,
				'layanan'		=> $layanan,
				'tarif'			=> $tarif

			);

			$this->clinicModel->insert_data($data, 'tb_layanan');
			$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
				  <strong>Data berhasil Ditambahkan</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
			redirect('admin/dataLayanan');

		}
	}


	// Awal Function Update Data
	public function updateData($id)
	{
		$where = array('id_layanan' => $id);
		$data['title'] = "Update Data Layanan";
		$data['layanan'] = $this->db->query("SELECT * FROM tb_layanan WHERE id_layanan='$id'")->result();
		$data['user'] = $this->session->userdata('nama');
		$data['tunggu']	= $this->db->query("SELECT * FROM tb_pelanggan
			WHERE status='2'
			ORDER BY tgl_daftar DESC")->result();
		$this->load->view('templates_admin/header',$data);
		$this->load->view('templates_admin/sidebar',$data);
		$this->load->view('admin/ubahdataLayanan',$data);
		$this->load->view('templates_admin/footer');
	}

	public function updateDataAksi()
	{
		$id = $this->input->post('id_layanan');
		$this->_rules();
		if ($this->form_validation->run() == FALSE) {
			$this->updateData($id);
		}else{
		
			$id 			= $this->input->post('id_layanan'); 
			$layanan 		= $this->input->post('layanan');
			$tarif 			= $this->input->post('tarif');

			$data= array(
				'layanan'		=> $layanan,
				'tarif'			=> $tarif
			);

			$where = array(
				'id_layanan' => $id
			);

			$this->clinicModel->update_data('tb_layanan',$data,$where);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
				  <strong>Data berhasil Diupdate</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
			redirect('admin/dataLayanan');
		}

	}
	

	// Awal Function Delete Data
	public function deleteData($id)
	{
		$where = array('id_layanan' => $id);
		$this->clinicModel->delete_data($where,'tb_layanan');
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				  <strong>Data berhasil Dihapus</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
			redirect('admin/dataLayanan');

	}

	public function _rules()
	{
		$this->form_validation->set_rules('id_layanan','ID Layanan','required');
		$this->form_validation->set_rules('layanan','Nama Layanan','required');
		$this->form_validation->set_rules('tarif','Tarif Layanan','required');

	}
}