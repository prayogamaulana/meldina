<?php 

/**
 * 
 */
class Dashboard extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		if($this->session->userdata('level') !='1'){
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				  <strong>Anda Belum Login!</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
				redirect('welcome');

		}
		
	}
	
	
	public function index()
	{
		$data['title'] = "Dashboard";
		$layanan = $this->db->query("SELECT * FROM tb_layanan");
		$daerah  = $this->db->query("SELECT * FROM tb_daerah");
		date_default_timezone_set('Asia/Jakarta');
		$pelangganaktif = $this->db->query("SELECT * FROM tb_pelanggan WHERE status='1' ");
		$pelangganputus = $this->db->query("SELECT * FROM tb_pelanggan WHERE status='3' ");
		$pelanggantunggu = $this->db->query("SELECT * FROM tb_pelanggan WHERE status='2' ");

		$thn = date('Y');
		$data['kategori'] = $this->db->query("SELECT date_format(tgl_daftar, '%M') AS kateg
       from tb_pelanggan
       WHERE year(tgl_daftar)='$thn'
       group by month(tgl_daftar)")->result();

		$data['jmlp1'] = $this->db->query("SELECT date_format(tgl_daftar, '%M %Y') AS bulan, COUNT(id_pelanggan) AS jml
       from tb_pelanggan
       WHERE status='1' AND year(tgl_daftar)='$thn'
       group by year(tgl_daftar),month(tgl_daftar)")->result();

		$data['jmlp2'] = $this->db->query("SELECT date_format(tgl_daftar, '%M %Y') AS bulan, COUNT(id_pelanggan) AS jml
       from tb_pelanggan
       WHERE status='2' AND year(tgl_daftar)='$thn'
       group by year(tgl_daftar),month(tgl_daftar)")->result();

		$data['jmlp3'] = $this->db->query("SELECT date_format(tgl_daftar, '%M %Y') AS bulan, COUNT(id_pelanggan) AS jml
       from tb_pelanggan
       WHERE status='3' AND year(tgl_daftar)='$thn'
       group by year(tgl_daftar),month(tgl_daftar)")->result();


		// $data['jmlp2'] = $this->db->query("SELECT date_format(FTGL_REG, '%M %Y') AS bulan,COUNT(FNO_REG) AS jml
  //      from t10_t_registrasi
  //      WHERE FSTAT='2' AND FJFAS='Asuransi' AND year(FTGL_REG)='$thn'
  //      group by year(FTGL_REG),month(FTGL_REG)")->result();
		
		// $data['jmlp3'] = $this->db->query("SELECT date_format(FTGL_REG, '%M %Y') AS bulan,COUNT(FNO_REG) AS jml
  //      from t10_t_registrasi
  //      WHERE FSTAT='2' AND FJFAS='BPJS' AND year(FTGL_REG)='$thn'
  //      group by year(FTGL_REG),month(FTGL_REG)")->result();

		$data['playanan'] 	= $this->db->query("SELECT tb_layanan.layanan AS nlayanan, COUNT(id_pelanggan) AS jml
       from tb_pelanggan
       JOIN tb_layanan ON tb_pelanggan.id_layanan=tb_layanan.id_layanan
       WHERE status='1'
       group by nlayanan")->result();

		$data['paktif'] = $pelangganaktif->num_rows();
		$data['pputus'] = $pelangganputus->num_rows();
		$data['ptunggu'] = $pelanggantunggu->num_rows();
		$data['jlayanan'] = $layanan->num_rows();
		$data['jdaerah'] = $daerah->num_rows();
		$data['user'] = $this->session->userdata('nama');
		$data['tunggu']	= $this->db->query("SELECT * FROM tb_pelanggan
			WHERE status='2'
			ORDER BY tgl_daftar DESC")->result();
		$this->load->view('templates_admin/header',$data);
		$this->load->view('templates_admin/sidebar',$data);
		$this->load->view('admin/dashboard',$data);
		$this->load->view('templates_admin/footer');
	}
}

 ?>