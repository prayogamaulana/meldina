<?php 

class PelangganTunggu extends CI_Controller{

	public function __construct()
	{
		parent::__construct();
		if($this->session->userdata('level') !='1'){
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				  <strong>Anda Belum Login!</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
				redirect('welcome');

		}

	}

	public function index()
	{
		$data['title'] = "Data Pelanggan Tunggu";
		$data['user'] = $this->session->userdata('nama');
		$data['pelanggan']	= $this->db->query("SELECT tb_pelanggan.*, tb_layanan.layanan
			FROM tb_pelanggan
			INNER JOIN tb_layanan ON tb_pelanggan.id_layanan=tb_layanan.id_layanan
			WHERE status='2'
			ORDER BY tgl_daftar DESC")->result();
		$data['tunggu']	= $this->db->query("SELECT * FROM tb_pelanggan
			WHERE status='2'
			ORDER BY tgl_daftar DESC")->result();
		$this->load->view('templates_admin/header',$data);
		$this->load->view('templates_admin/sidebar',$data);
		$this->load->view('admin/pelangganTunggu',$data);
		$this->load->view('templates_admin/footer');
	}


	public function aktifkan($id)
	{

			$data= array(
				'status'			=> "1"
			);

			$where = array(
					'id_pelanggan' => $id
			);

			$this->clinicModel->update_data('tb_pelanggan',$data,$where);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
				  <strong>Pelanggan Berhasil Diaktifkan</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
			redirect('admin/dataPelanggan');

		
	}

	// Awal Function Delete Data
	public function deleteData($id)
	{
	
		$where = array(
            'id_pelanggan' => $id
        );
		$this->clinicModel->delete_data($where,'tb_pelanggan');
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				  <strong>Data berhasil Dihapus</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
		echo redirect('admin/pelangganTunggu');

	}

}

 ?>