<?php 

/**
 * 
 */
class DataUser extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		if($this->session->userdata('level') !='1'){
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				  <strong>Anda Belum Login!</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
				redirect('welcome');

		}
		
	}


	public function index()
	{

		$data['title'] = "Data Pengguna";
		$data['pengguna'] = $this->clinicModel->get_data('t00_m_users')->result();
		$data['tunggu']	= $this->db->query("SELECT * FROM tb_pelanggan
			WHERE status='2'
			ORDER BY tgl_daftar DESC")->result();
		$this->load->view('templates_admin/header',$data);
		$this->load->view('templates_admin/sidebar',$data);
		$this->load->view('admin/dataUser',$data);
		$this->load->view('templates_admin/footer');
	}

	public function tambahData()
	{
		$data['title'] = "Tambah Data User";
		$data['fcom'] = $this->clinicModel->cek_address();
		$data['tunggu']	= $this->db->query("SELECT * FROM tb_pelanggan
			WHERE status='2'
			ORDER BY tgl_daftar DESC")->result();
		$this->load->view('templates_admin/header',$data);
		$this->load->view('templates_admin/sidebar',$data);
		$this->load->view('admin/tambahDataUser',$data);
		$this->load->view('templates_admin/footer');
	}

	public function tambahDataAksi()
	{
		$this->_rules();
		if ($this->form_validation->run() == FALSE) {
			$this->tambahData();
		}else{
			$nama 		= $this->input->post('nama');
			$username 	= $this->input->post('username');
			$password 	= $this->input->post('password');
			$hash = password_hash($password, PASSWORD_DEFAULT);
			$level 		= $this->input->post('level');
			$photo 			= $_FILES['photo']['name'];
			if($photo=''){}else{
				$config ['upload_path']		= './assets/photo';
				$config ['allowed_types']	= 'jpg|jpeg|png|tiff';
				$this->load->library('upload',$config);
				if(!$this->upload->do_upload('photo')){
					echo "Photo Gagal diupload!";
				}else{
					$photo=$this->upload->data('file_name');
				}
			}


			$data= array(

				'nama'		=> $nama,
				'username'	=> $username,
				'password'	=> $hash,
				'level'		=> $level,
				'photo' 	=> $photo
			);

			$this->clinicModel->insert_data($data,'t00_m_users');
			$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
				  <strong>Data berhasil Ditambahkan</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
			redirect('admin/dataUser');

		}
	}

	public function updateData($id)
	{
		$where = array('iduser' => $id);
		$data['pengguna'] = $this->db->query("SELECT * FROM t00_m_users
			WHERE iduser ='$id'")->result();
		// $data['pasien'] = $this->db->query("SELECT * FROM t00_m_pasien WHERE FNO_RM='$id'")->result();
		$data['title'] = "Edit Data User";
		$data['fcom'] = $this->clinicModel->cek_address();
		$data['tunggu']	= $this->db->query("SELECT * FROM tb_pelanggan
			WHERE status='2'
			ORDER BY tgl_daftar DESC")->result();
		$this->load->view('templates_admin/header',$data);
		$this->load->view('templates_admin/sidebar',$data);
		$this->load->view('admin/ubahDataUser',$data);
		$this->load->view('templates_admin/footer');

	}

	public function updateDataAksi()
	{
		$id 		= $this->input->post('iduser');
		$this->_rulesupdate();
		if ($this->form_validation->run() == FALSE) {
			$this->updateData($id);
		}else{
			$id 		= $this->input->post('iduser');
			$nama 		= $this->input->post('nama');
			$username 	= $this->input->post('username');
			$password 	= $this->input->post('password');
			$hash = password_hash($password, PASSWORD_DEFAULT);
			$level 		= $this->input->post('level');
			$photo 		= $_FILES['photo']['name'];
			if($photo){
				$config ['upload_path']		= './assets/photo';
				$config ['allowed_types']	= 'jpg|jpeg|png|tiff';
				$this->load->library('upload',$config);
				if($this->upload->do_upload('photo')){
					$photo=$this->upload->data('file_name');
					$this->db->set('photo',$photo);
					
				}else{
					echo $this->upload->display_errors();
				}
			}
			if ($_POST['password']!='') {
				$data= array(
				'nama'		=> $nama,
				'password'	=> $hash,
				'level'		=> $level,
				'photo'		=> $photo
				);
			}else {
				$data= array(
				'nama'		=> $nama,
				'level'		=> $level,
				'photo'		=> $photo
				);
			}

			$where = array(
					'iduser' => $id,
					'username'	=> $username
			);

			$this->clinicModel->update_data('t00_m_users',$data,$where);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
				  <strong>Data berhasil Di Update</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
			redirect('admin/dataUser');
		}
	}

	public function deleteData($id)
	{
		$where = array('iduser' => $id);
		$this->clinicModel->delete_data($where,'t00_m_users');
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				  <strong>Data berhasil Dihapus</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
			redirect('admin/dataUser');

	}

	public function _rules()
	{
		$this->form_validation->set_rules('username','Username','required|is_unique[t00_m_users.username]');
		$this->form_validation->set_rules('password','Password','required');
		$this->form_validation->set_rules('nama','Nama User','required');
		$this->form_validation->set_rules('level','Level','required');

	}

	public function _rulesupdate()
	{
		$this->form_validation->set_rules('username','Username','required');
		$this->form_validation->set_rules('nama','Nama User','required');
		$this->form_validation->set_rules('level','Level','required');

	}


}



 ?>