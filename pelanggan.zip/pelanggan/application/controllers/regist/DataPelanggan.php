<?php 

class DataPelanggan extends CI_Controller{

	public function __construct()
	{
		parent::__construct();
		if($this->session->userdata('level') !='3'){
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				  <strong>Anda Belum Login!</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
				redirect('welcome');

		}

	}

	public function index()
	{
		$data['title'] = "Data Pelanggan Terdaftar";
		$data['user'] = $this->session->userdata('nama');
		$data['pelanggan']	= $this->db->query("SELECT tb_pelanggan.*, tb_layanan.layanan
		$data['pelanggan']	= $this->db->query("SELECT tb_pelanggan.*, tb_daerah.daerah
			FROM tb_pelanggan
			INNER JOIN tb_layanan ON tb_pelanggan.id_layanan=tb_layanan.id_layanan
			INNER JOIN tb_daerah ON tb_pelanggan.id_daerah=tb_daerah.id_daerah
			WHERE status='2'
			ORDER BY tgl_daftar DESC")->result();
		$this->load->view('templates_regist/header',$data);
		$this->load->view('templates_regist/sidebar',$data);
		$this->load->view('regist/dataPelanggan',$data);
		$this->load->view('templates_regist/footer');
	}


	// Awal Function Tambah Data
	public function tambahData()
	{
		$data['title'] = "Tambah Data Pelanggan";
		$data['layanan'] = $this->clinicModel->get_data('tb_layanan')->result();
		$data['kodeunik'] = $this->clinicModel->buat_kode();
		$this->load->view('templates_regist/header',$data);
		$this->load->view('templates_regist/sidebar',$data);
		$this->load->view('regist/tambahDataPelanggan',$data);
		$this->load->view('templates_regist/footer');
	}

	// Awal Function Tambah Data
	public function tambahData()
	{
		$data['title'] = "Tambah Data Pelanggan";
		$data['daerah'] = $this->clinicModel->get_data('tb_daerah')->result();
		$data['kodeunik'] = $this->clinicModel->buat_kode();
		$this->load->view('templates_regist/header',$data);
		$this->load->view('templates_regist/sidebar',$data);
		$this->load->view('regist/tambahDataPelanggan',$data);
		$this->load->view('templates_regist/footer');
	}


	public function tambahDataAksi()
	{
		$this->_rules();
		if ($this->form_validation->run() == FALSE) {
			$this->tambahData();
		}else{
			$id_pelanggan 		= $this->input->post('id_pelanggan');
			$nama_pelanggan		= $this->input->post('nama_pelanggan');
			$no_hp 				= $this->input->post('no_hp');
			$tgl_daftar 		= $this->input->post('tgl_daftar');
			$alamat 			= $this->input->post('alamat');
			$id_layanan 		= $this->input->post('id_layanan');
			$id_daerah	 		= $this->input->post('id_daerah');


			$data= array(

				'id_pelanggan'		=> $id_pelanggan,
				'nama_pelanggan'	=> $nama_pelanggan,
				'no_hp'				=> $no_hp,
				'tgl_daftar'		=> $tgl_daftar,
				'alamat'			=> $alamat,
				'id_layanan'		=> $id_layanan,
				'id_daerah'			=> $id_daerah,
				'status'			=> "2"


			);

			$this->clinicModel->insert_data($data, 'tb_pelanggan');
			$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
				  <strong>Data berhasil Ditambahkan</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
			redirect('regist/dataPelanggan');

		}
	}
// Akhir Function Tambah Data

	// Awal Function Update Data
	public function updateData($id)
	{

		$where = array(
            'id_pelanggan' => $id
        );


		
		$data['pelanggan'] = $this->db->query("SELECT tb_pelanggan.*, tb_layanan.layanan as nlayanan
			FROM tb_pelanggan
			INNER JOIN tb_layanan ON tb_pelanggan.id_layanan=tb_layanan.id_layanan
			WHERE tb_pelanggan.id_pelanggan='$id'")->result();
		$data['title'] = "Edit Data Pelanggan";
		$data['layanan'] = $this->clinicModel->get_data('tb_layanan')->result();
		$this->load->view('templates_regist/header',$data);
		$this->load->view('templates_regist/sidebar',$data);
		$this->load->view('regist/ubahDataPelanggan',$data);
		$this->load->view('templates_regist/footer');
	}

	public function updateDataAksi()
	{
		$id = $this->input->post('id_pelanggan');
		$this->_rulesupdate();
		if ($this->form_validation->run() == FALSE) {
			$this->updateData($id);
		}else{
			$nama_pelanggan	= $this->input->post('nama_pelanggan');
			$no_hp 			= $this->input->post('no_hp');
			$tgl_daftar 	= $this->input->post('tgl_daftar');
			$alamat 		= $this->input->post('alamat');
			$id_layanan 	= $this->input->post('id_layanan');
			$id_daerah	 	= $this->input->post('id_daerah');

			$data= array(
				'nama_pelanggan'	=> $nama_pelanggan,
				'no_hp'				=> $no_hp,
				'tgl_daftar'		=> $tgl_daftar,
				'alamat'			=> $alamat,
				'id_layanan'		=> $id_layanan
				'id_daerah'			=> $id_daerah
			);

			$where = array(
					'id_pelanggan' => $id
			);

			$this->clinicModel->update_data('tb_pelanggan',$data,$where);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
				  <strong>Data berhasil Di Update</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
			redirect('regist/dataPelanggan');
		}

		
	}

	public function _rules()
	{
		$this->form_validation->set_rules('id_pelanggan','ID Pelanggan','required');
		$this->form_validation->set_rules('nama_pelanggan','Nama Pelanggan','required');
		$this->form_validation->set_rules('tgl_daftar','Tanggal Daftar','required');
		$this->form_validation->set_rules('alamat','Alamat','required');
		$this->form_validation->set_rules('no_hp','Nomor Telp','numeric|max_length[15]');
		$this->form_validation->set_rules('id_layanan','Layanan','required');
		$this->form_validation->set_rules('id_daerah','daerah','required');

	}

	public function _rulesupdate()
	{
		$this->form_validation->set_rules('nama_pelanggan','Nama Pelanggan','required');
		$this->form_validation->set_rules('tgl_daftar','Tanggal Daftar','required');
		$this->form_validation->set_rules('alamat','Alamat','required');
		$this->form_validation->set_rules('no_hp','Nomor Telp','numeric|max_length[15]');
		$this->form_validation->set_rules('id_layanan','Layanan','required');
		$this->form_validation->set_rules('id_daerah','daerah','required');

	}

	public function cetakPelanggan($id)
	{
		$where = array('id_pelanggan' => $id);
		// panggil library yang kita buat sebelumnya yang bernama pdfgenerator
        $this->load->library('pdfgenerator');
        
        // title dari pdf
        $this->data['title'] = "Detail Pelanggan";
        $this->data['pelanggan'] = $this->db->query("SELECT tb_pelanggan.*, tb_layanan.layanan as nlayanan
			FROM tb_pelanggan
			INNER JOIN tb_layanan ON tb_pelanggan.id_layanan=tb_layanan.id_layanan
			WHERE tb_pelanggan.id_pelanggan='$id'")->result();
        
        // filename dari pdf ketika didownload
        $file_pdf = 'Detail Pelanggan-'.$id;
        // setting paper
        $paper = 'F4';
        //orientasi paper potrait / landscape
        $orientation = "portrait";
        
		$html = $this->load->view('laporan/cetakPelanggan',$this->data,true);	    
        
        // run dompdf
        $this->pdfgenerator->generate($html, $file_pdf,$paper,$orientation);

	}



}

 ?>