<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */

	public function index()
	{
		$data['title'] = "Meldina Network";
		$this->load->view('templates_admin/header',$data);
		$this->load->view('login');
	}

	public function login()
	{
		$this->_rules();

		if ($this->form_validation->run()==FALSE) {
			$this->index();
		}else{
			$username = $this->input->post('username');
			$pass = $this->input->post('password');
			// $pass 	= mysqli_real_escape_string($_POST['password']);
			$query = $this->db->query("SELECT * FROM t00_m_users WHERE username='$username'");
			if ($query->num_rows()>0) {
				foreach ($query->result() as $k) {
					$hash = $k->password;
					if (password_verify($pass,$hash)) {
						$this->session->set_userdata('level', $k->level);
						$this->session->set_userdata('iduser', $k->iduser);
						$this->session->set_userdata('nama', $k->nama);
						$this->session->set_userdata('photo', $k->photo);
						
						switch ($k->level) {
							case 1 :
								redirect('admin/dashboard');
								break;
							case 2 :
								redirect('pimpinan/dashboard');
								break;
							case 3 :
								redirect('regist/dashboard');
								break;
							
							default:
								break;
						}
					}else{
						$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
						  <strong>Password Tidak Sesuai !</strong>
						  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						</div>');
							redirect('welcome');

					}
				}
				
			}else{
				$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				  <strong>Username tidak Ditemukan !</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
				redirect('welcome');

			}

		}

	}



	public function _rules()
	{
		$this->form_validation->set_rules('username','Username','required');
		$this->form_validation->set_rules('password','Password','required');
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect('welcome');
	}

}
