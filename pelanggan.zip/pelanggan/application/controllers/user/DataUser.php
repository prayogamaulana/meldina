<?php 

/**
 * 
 */
class DataUser extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		if($this->session->userdata('level') == ""){
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				  <strong>Anda Belum Login!</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
				redirect('welcome');

		}
	}


	public function index()
	{
		$id = $this->session->userdata('iduser');
		$level = $this->session->userdata('level');
		$data['pengguna'] = $this->db->query("SELECT * FROM T00_M_USERS
			WHERE iduser ='$id'")->result();
		// $data['pasien'] = $this->db->query("SELECT * FROM t00_m_pasien WHERE FNO_RM='$id'")->result();
		$data['title'] = "Edit Data User";
		$data['fcom'] = $this->clinicModel->cek_address();

		if ($level==2) {
			$this->load->view('templates_pimpinan/header',$data);
			$this->load->view('templates_pimpinan/sidebar');
			$this->load->view('user/dataUser',$data);
			$this->load->view('templates_pimpinan/footer');
		}elseif ($level==3) {
			$this->load->view('templates_regist/header',$data);
			$this->load->view('templates_regist/sidebar');
			$this->load->view('user/dataUser',$data);
			$this->load->view('templates_regist/footer');
		}

	}

	public function updateDataAksi()
	{
		$id 		= $this->input->post('iduser');
		$this->_rulesupdate();
		if ($this->form_validation->run() == FALSE) {
			$this->index();
		}else{
			$id 		= $this->input->post('iduser');
			$nama 		= $this->input->post('nama');
			$username 	= $this->input->post('username');
			$password 	= $this->input->post('password');
			$hash = password_hash($password, PASSWORD_DEFAULT);
			$photo 		= $_FILES['photo']['name'];
			if($photo){
				$config ['upload_path']		= './assets/photo';
				$config ['allowed_types']	= 'jpg|jpeg|png|tiff';
				$this->load->library('upload',$config);
				if($this->upload->do_upload('photo')){
					$photo=$this->upload->data('file_name');
					$this->db->set('photo',$photo);
					
				}else{
					echo $this->upload->display_errors();
				}
			}
			if ($_POST['password']!='') {
				$data= array(
				'nama'		=> $nama,
				'password'	=> $hash,
				'photo'		=> $photo
				);
			}else {
				$data= array(
				'nama'		=> $nama,
				'photo'		=> $photo
				);
			}

			$where = array(
					'iduser' => $id,
					'username'	=> $username
			);

			$this->clinicModel->update_data('T00_M_USERS',$data,$where);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
				  <strong>Data berhasil Di Update</strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>');
			redirect('user/dataUser');
		}
	}


	public function _rulesupdate()
	{
		$this->form_validation->set_rules('username','Username','required');
		$this->form_validation->set_rules('nama','Nama User','required');

	}


}



 ?>