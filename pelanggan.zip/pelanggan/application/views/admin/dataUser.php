<div class="container-fluid">

  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
    
  </div>

<?php echo $this->session->flashdata('pesan') ?>
<a class="btn btn-sm btn-success mb-3" title="Tambah Data Dokter" href="<?php echo base_url('admin/dataUser/tambahData') ?>"><i class="fas fa-plus"></i>Tambah User</a>
<!-- <a class="btn btn-sm btn-info ml-auto mb-3" title="Cetak Data Dokter" target='_blank' href="<?php echo base_url('laporan/lapDokter') ?>"><i class="fas fa-print"></i> Cetak Data</a> -->
<div class="card shadow mb-4">
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-sm table-bordered" id="dataTable">
        <thead>
      	 <tr>
        		<th class="text-center">No</th>
            <th class="text-center">Nama Pengguna</th>
        		<th class="text-center">Username</th>
            <th class="text-center">Level</th>
        		<th class="text-center">Photo</th>
        		<th class="text-center">Action</th>
        	</tr>
        </thead>
        	
        <tbody>
          <?php $no=1;foreach ($pengguna as $p) : 
            $stat   = $p->level;
            $statlevel  = "";
            if ($stat==1) {
              $statlevel = "Admin";
            }elseif ($stat==2) {
              $statlevel = "Pimpinan";
            }elseif ($stat==3) {
              $statlevel = "Register";
            }elseif ($stat==4) {
              $statlevel = "Kasir";
            }elseif ($stat==5) {
              $statlevel = "Dokter";
            }
          ?>
        	<tr>
        		<td><?php echo $no++ ?></td>
        		<td><?php echo $p->nama ?></td>
        		<td><?php echo $p->username ?></td>
        		<td><?php echo $statlevel ?></td>
        		<td class="text-center"><img src="<?php echo base_url().'assets/photo/'.$p->photo ?>" width="75px"></td>
        		<td>
        			<center>
      				<a class="btn btn-sm btn-warning" title="Ubah Data User" href="<?php echo base_url('admin/dataUser/updateData/'.$p->iduser) ?>"><i class="fas fa-edit"></i></a>
      				<a onclick="return confirm('Yakin Akan Meghapus Data ?')" class="btn btn-sm btn-danger" title="Hapus Data Dokter" href="<?php echo base_url('admin/dataUser/deleteData/'.$p->iduser) ?>"><i class="fas fa-trash"></i></a>
      			</center>
        		</td>

        	</tr>
          <?php endforeach; ?>
        </tbody>
        
      </table>
    </div>
  </div>
</div>


</div>