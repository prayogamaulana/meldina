<div class="container-fluid">
  <div class="card shadow mb-4">
  <div class="card-header">
    <b>Ubah Data Daerah</b>
  </div>

  <div class="card-body">
    <?php foreach ($daerah as $p): ?>
    <form method="POST" action="<?php echo base_url('admin/dataDaerah/updateDataAksi') ?>" class="row g-3 needs-validation" >
      <div class="col-md-3">
        <label>ID DAERA</label>

        <input type="text" name="id_daerah" class="form-control" readonly value="<?php echo $p->id_daerah ?>" size="30">
                <?php echo form_error('id_daerah', '<div class="text-small text-danger"></div>') ?>   
      </div>

      <div class="col-md-3">
        <label>Nama Daerah</label>    
        <input type="text" name="daerah" value="<?php echo set_value('daerah',$p->daerah); ?>" placeholder="Nama Daerah" class="form-control" size="30">
                <?php echo form_error('daerah', '<div class="text-small text-danger"></div>') ?>
      </div>

      <div class="mx-auto my-auto">
        <button type="submit" class="btn btn-info">Simpan</button>
        <a class="btn btn-warning mx-3" href="<?php echo base_url('admin/dataDaerah') ?>">Batal</a>
      </div>

    </form>
    <?php endforeach; ?>
  </div>
</div>
</div>