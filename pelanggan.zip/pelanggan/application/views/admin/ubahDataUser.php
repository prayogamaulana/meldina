
<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h5 class="h5 mb-0 text-gray-800"><?php echo $title ?></h5>
  </div>

<div class="card mb-4">
  <div class="card-body">
<?php foreach ($pengguna as $p) { ?>
  

    <form method="POST" class="form-inline" action="<?php echo base_url('admin/dataUser/updateDataAksi') ?>" enctype="multipart/form-data">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="container">
              <div class="row mb-3">
                <div class="col-4">
                  <label>Nama Pengguna</label>
                </div>
                <div class="col">
                  <input type="text" name="iduser" hidden class="form-control" value="<?php echo set_value('iduser',$p->iduser); ?>" size="30">
                  <input type="text" name="nama" placeholder="Masukan Nama User" class="form-control" value="<?php echo set_value('nama',$p->nama); ?>" size="30">
                  <?php echo form_error('nama', '<div class="text-small text-danger"></div>') ?>
                </div>
              </div>

              <div class="row mb-3">
                <div class="col-4">
                  <label>Username</label>
                </div>
                <div class="col">
                  <input type="text" readonly name="username" class="form-control" placeholder="Username untuk login" value="<?php echo set_value('username',$p->username); ?>" size="30">
                  <?php echo form_error('username', '<div class="text-small text-danger"></div>') ?>
                </div>
              </div>

              <div class="row mb-3">
                <div class="col-4">
                  <label>Ubah Password</label>
                </div>
                <div class="col">
                  <input type="password" name="password" placeholder="Biarkan Kosong Jika tidak diubah" class="form-control form-password" value="<?php echo set_value('password'); ?>" size="30">
                  <?php echo form_error('password', '<div class="text-small text-danger"></div>') ?>
                  <input type="checkbox" class="form-checkbox"> Show password
                </div>
              </div>

              <div class="row mb-3">
                <div class="col-4">
                  <label>Level</label>
                </div>
                <div class="col">
                  <select name="level" id="jpajak" class="form-control">
                    <option value="" <?php echo ($p->level == "") ? 'selected' : '' ?>>--Pilih Level--</option>
                    <option value="1" <?php echo ($p->level == "1") ? 'selected' : ''?>>Admin</option>
                    <option value="2" <?php echo ($p->level == "2") ? 'selected' : ''?>>Pimpinan</option>
                    <option value="3" <?php echo ($p->level == "3") ? 'selected' : ''?>>Register</option>
                    <option value="4" <?php echo ($p->level == "4") ? 'selected' : ''?>>Kasir</option>
                    <option value="5" <?php echo ($p->level == "5") ? 'selected' : ''?>>Dokter</option>
                  </select>
                  <?php echo form_error('level', '<div class="text-small text-danger"></div>') ?>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-4">
                  <label>Photo</label>
                </div>
                <div class="col">
                  <input type="file" name="photo" class="form-control">
                <?php echo form_error('photo', '<div class="text-small text-danger"></div>') ?>
                </div>
              </div>

          <div class="row justify-content-center">
            <div class="col-6">
              <a class="btn btn-warning mx-3" href="<?php echo base_url('admin/dataUser') ?>">Cancle</a>
              <button type="submit" class="btn btn-success">Simpan</button>
            </div>
          </div>

          </div>
        </div>
      </div>  
    </form>
<?php } ?>
  </div>
</div>



</div>
<!-- End of Main Content -->

<script type="text/javascript">
  $(document).ready(function(){   
    $('.form-checkbox').click(function(){
      if($(this).is(':checked')){
        $('.form-password').attr('type','text');
      }else{
        $('.form-password').attr('type','password');
      }
    });
  });
</script>