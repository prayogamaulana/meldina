
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <!-- <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
            
          </div> -->

          <!-- Content Row -->
          
          
           <div class="row">
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                
                <div class="card-body" title="Jumlah Layanan">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"><a class="collapse-item" href="<?php echo base_url('admin/dataLayanan') ?>">Paket Internet</a></div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $jlayanan ?></div>
                    </div>
                    <div class="col-auto">
                      <a href="#">
                      <i class="fas fa-users fa-2x text-gray-300"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-success shadow h-100 py-2">
                
                <div class="card-body" title="Jumlah Pelanggan Aktif">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                  <a class="collapse-item" href="<?php echo base_url('admin/dataPelanggan') ?>">Pelanggan Aktif</a></div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $paktif ?></div>
                    </div>
                    <div class="col-auto">
                      <a href="#">
                      <i class="fas fa-user-md fa-2x text-gray-300"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-info shadow h-100 py-2">
                
                <div class="card-body" title="Jumlah Pelanggan Diputus">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1"><a class="collapse-item" href="<?php echo base_url('admin/pelangganTunggu') ?>">Menunggu Pemasangan</a></div>
                      <div class="row no-gutters align-items-center">
                        <div class="col-auto">
                          <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo $ptunggu ?></div>
                        </div>
                        
                      </div>
                    </div>
                    <div class="col-auto">
                      <a href="#">
                      <i class="fas fa-wheelchair fa-2x text-gray-300"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-danger shadow h-100 py-2">
                
                <div class="card-body" title="Jumlah Pelanggan Menunggu Pemasangan">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-danger text-uppercase mb-1"><a class="collapse-item" href="<?php echo base_url('admin/pelangganPutus') ?>">Pelanggan Diputus</a></div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $pputus ?></div>
                    </div>
                    <div class="col-auto">
                      <a href="#">
                      <i class="fas fa-stethoscope fa-2x text-gray-300"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Content Row -->
          <div class="row">
            <!-- Chart Pasien -->
            <div class="col-xl-7 col-md-6 mb-4">
              <div class="card shadow h-100">
                <div class="card-header bg-info text-white ">
                  Grafik Pelanggan Tahun <?php echo date('Y'); ?>
                </div>
                <div class="card-body text-center" title="Data Periodik Pelanggan">
                    <div id="pasienf">
                      
                    </div>
                </div>
              </div>
            </div>

            <div class="col-xl-5 col-md-6 mb-4">
              <div class="card shadow h-100">

                <div class="card-header bg-warning text-white">
                  Pelanggan Tiap Layanan
                </div>
                <div class="card-body" title="Data Periodik Pelanggan Per Layanan">
                    <figure class="highcharts-figure">
                    <div id="pasienp">
                       
                    </div>
                  </figure>
                </div>
              </div>
            </div>



          </div>
          

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->


<script> 
 
$(function () {

  Highcharts.chart('pasienp', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'Data Pelanggan Aktif Berdasarkan Layanan'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    accessibility: {
        point: {
            valueSuffix: '%'
        }
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true
            },
            showInLegend: true
        }
    },
    series: [{
      type: 'pie',
      name: 'Persentase Pelanggan',
      data: [
          <?php 
          // data yang diambil dari database
          if(count($playanan)>0)
          {
             foreach ($playanan as $pp) {
             echo "['" .$pp->nlayanan . "'," . $pp->jml ."],\n";
             }
          }
          ?>
      ]
    }]
});


});
 
</script>

<script>
  $(function() {

    Highcharts.chart('pasienf', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Data Pelanggan'
    },
    subtitle: {
        text: 'Source: <a href="<?php echo base_url('admin/dashboard') ?>" target="_blank">Meldina Network</a>'
    },
    xAxis: {
        
        categories: [
        <?php 
          // data yang diambil dari database
         
             foreach ($kategori as $kt) {
             echo "['" .$kt->kateg . "'],\n";
             }
         
          ?>
          ],
        tickmarkPlacement: 'on',
        title: {
            enabled: false
        }
    },
    yAxis: {
        title: {
            text: 'Jumlah Pelanggan'
        },
        labels: {
            formatter: function () {
                return this.value;
            }
        }
    },
    tooltip: {
        split: false,
        valueSuffix: ' org'
    },
    plotOptions: {
        area: {
            stacking: 'normal',
            lineColor: '#666666',
            lineWidth: 1,
            marker: {
                lineWidth: 1,
                lineColor: '#666666'
            }
        }
    },
    series: [{
      name: 'Pelanggan Aktif',
      data: [
          <?php 
          // data yang diambil dari database
          
             foreach ($jmlp1 as $jp1) {
             echo "['" .$jp1->bulan . "'," . $jp1->jml ."],\n";
             }
        
          ?>
      ]
    }, {
      name: 'Menunggu Pemasangan',
      data: [
          <?php 
          // data yang diambil dari database
          
             foreach ($jmlp2 as $jp2) {
             echo "['" .$jp2->bulan . "'," . $jp2->jml ."],\n";
             }
          
          ?>
      ]
    }, {
      name: 'Diputuskan',
      data: [
          <?php 
          // data yang diambil dari database
          
             foreach ($jmlp3 as $jp3) {
             echo "['" .$jp3->bulan . "'," . $jp3->jml ."],\n";
             }
     
          ?>
      ]
    }]

});



  })
</script>