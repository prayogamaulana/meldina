<div class="container-fluid">

  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
    
  </div>

<?php echo $this->session->flashdata('pesan') ?>
<div class="card shadow mb-4">
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable">
        <thead>
      	 <tr>
        		<th class="text-center">No</th>
            <th class="text-center">ID Pelanggan</th>
            <th class="text-center">Nama</th>
            <th class="text-center">Alamat</th>
            <th class="text-center">No HP</th>
            <th class="text-center">Tgl Daftar</th>
            <th class="text-center">Layanan</th>
            <th class="text-center">Status</th>
        		<th class="text-center">Action</th>
        	</tr>
        </thead>
        	
        <tbody>
          <?php $no=1;foreach ($pelanggan as $p) : 
          $stat = $p->status;?>
        	<tr>
        		<td><?php echo $no++ ?></td>
        		<td><?php echo $p->id_pelanggan ?></td>
            <td><?php echo $p->nama_pelanggan ?></td>
            <td><?php echo $p->alamat ?></td>
            <td><?php echo $p->no_hp ?></td>
            <td><?php echo date('d-m-Y',strtotime($p->tgl_daftar)) ?></td>
            <td><?php echo $p->layanan ?></td>
            <td> <center>
              <?php
               if($stat=='1'){ ?>
                <span class="badge badge-success"><i class="fas fa-check-circle"></i> Aktif</span>
          <?php }elseif($stat=='3'){ ?>
              <span class="badge badge-danger"><i class="fas fa-ban"></i>Tidak Aktif</span>
               <?php }elseif($stat=='2'){ ?>
              <span class="badge badge-warning"><i class="fas fa-warning"></i>Tunggu Pasang</span>
              <?php } ?>
              </center>
            </td>
        		<td>
        			<center>
      				<!-- <a class="btn btn-sm btn-success" href="<?php echo base_url('admin/pelangganTunggu/aktifkan/'.$p->id_pelanggan) ?>" title="Aktifkan Pelanggan"><i class="fas fa-check-circle"></i></a> -->
              <a onclick="return confirm('Yakin Akan Mengaktifkan Pelanggan Ini ?')" class="btn btn-sm btn-info" href="<?php echo base_url('admin/pelangganTunggu/aktifkan/'.$p->id_pelanggan) ?>" title="Aktifkan Pelanggan"><i class="fas fa-check-circle"></i></a>
      				<a onclick="return confirm('Yakin Akan Meghapus Data Pelanggan Berikut ?')" class="btn btn-sm btn-danger" href="<?php echo base_url('admin/pelangganTunggu/deleteData/'.$p->id_pelanggan) ?>"><i class="fas fa-trash"></i></a>
      			</center>
        		</td>

        	</tr>
          <?php endforeach; ?>
        </tbody>
        
      </table>
    </div>
  </div>
</div>


</div>