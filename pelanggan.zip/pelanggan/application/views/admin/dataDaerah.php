<div class="container-fluid">

  <!-- Page Heading -->
  <!-- <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
    
  </div> -->

<?php echo $this->session->flashdata('pesan') ?>

<div class="card shadow mb-4">
  <div class="card-header">
    <b>Tambah Daerah</b>
  </div>

  <div class="card-body">
    <form method="POST" action="<?php echo base_url('admin/dataDaerah/tambahDataAksi') ?>" class="row g-3 needs-validation" >
      <div class="col-md-3">
        <label>ID DAERAH</label>
        <input type="text" name="id_daerah" class="form-control" readonly value="<?php echo $kodeunik ?>" size="30">
                <?php echo form_error('id_daerah', '<div class="text-small text-danger"></div>') ?>   
      </div>

      <div class="col-md-4">
        <label>Nama Daerah</label>    
        <input type="text" name="daerah" value="<?php echo set_value('daerah'); ?>" placeholder="Nama Daerah" class="form-control" size="30">
                <?php echo form_error('daerah', '<div class="text-small text-danger"></div>') ?>
      </div>


      <div class="mx-auto my-auto">
        <button type="submit" class="btn btn-info">Simpan</button>
      </div>

    </form>

  </div>
</div>



<div class="card shadow mb-4">
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-hover table-sm table-bordered" id="dataTable">
        <thead>
      	 <tr>
        		<th class="text-center">No</th>
            <th class="text-center">ID Daerah</th>
            <th class="text-center">Nama Daerah</th>
        		<th class="text-center">Action</th>
        	</tr>
        </thead>
        	
        <tbody>
          <?php $no=1;foreach ($daerah as $p) :
          ?>
        	<tr>
        		<td class="text-center"><?php echo $no++ ?></td>
        		<td><?php echo $p->id_daerah ?></td>
            <td><?php echo $p->daerah ?></td>
        		<td>
        			<center>
      				<a class="btn btn-sm btn-warning" href="<?php echo base_url('admin/dataDaerah/updateData/'.$p->id_daerah) ?>"><i class="fas fa-edit"></i></a>
      				<a onclick="return confirm('Yakin Akan Meghapus Data ?')" class="btn btn-sm btn-danger" href="<?php echo base_url('admin/dataDaerah/deleteData/'.$p->id_daerah) ?>"><i class="fas fa-trash"></i></a>
      			</center>
        		</td>

        	</tr>
          <?php endforeach; ?>
        </tbody>
        
      </table>
    </div>
  </div>
</div>


</div>