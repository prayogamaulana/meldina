<div class="container-fluid">

  <!-- Page Heading -->
  <!-- <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
    
  </div> -->

<?php echo $this->session->flashdata('pesan') ?>

<div class="card shadow mb-4">
  <div class="card-header">
    <b>Tambah Data Layanan</b>
  </div>

  <div class="card-body">
    <form method="POST" action="<?php echo base_url('admin/dataLayanan/tambahDataAksi') ?>" class="row g-3 needs-validation" >
      <div class="col-md-3">
        <label>ID Layanan</label>
        <input type="text" name="id_layanan" class="form-control" readonly value="<?php echo $kodeunik ?>" size="30">
                <?php echo form_error('id_layanan', '<div class="text-small text-danger"></div>') ?>   
      </div>

      <div class="col-md-4">
        <label>Nama Layanan</label>    
        <input type="text" name="layanan" value="<?php echo set_value('layanan'); ?>" placeholder="Nama Layanan" class="form-control" size="30">
                <?php echo form_error('layanan', '<div class="text-small text-danger"></div>') ?>
      </div>

      <div class="col-md-3">
        <label>Tarif Rp.</label>    
        <input type="number" name="tarif" value="<?php echo set_value('tarif'); ?>" placeholder="Rp. " class="form-control" size="30">
                <?php echo form_error('tarif', '<div class="text-small text-danger"></div>') ?>
      </div>

      <div class="mx-auto my-auto">
        <button type="submit" class="btn btn-info">Simpan</button>
      </div>

    </form>

  </div>
</div>



<div class="card shadow mb-4">
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-hover table-sm table-bordered" id="dataTable">
        <thead>
      	 <tr>
        		<th class="text-center">No</th>
            <th class="text-center">ID Layanan</th>
            <th class="text-center">Nama Layanan</th>
            <th class="text-center">Tarif</th>
        		<th class="text-center">Action</th>
        	</tr>
        </thead>
        	
        <tbody>
          <?php $no=1;foreach ($layanan as $p) :
          ?>
        	<tr>
        		<td class="text-center"><?php echo $no++ ?></td>
        		<td><?php echo $p->id_layanan ?></td>
            <td><?php echo $p->layanan ?></td>
            <td class="text-right">Rp. <?php echo number_format($p->tarif) ?>,-</td>
        		<td>
        			<center>
      				<a class="btn btn-sm btn-warning" href="<?php echo base_url('admin/dataLayanan/updateData/'.$p->id_layanan) ?>"><i class="fas fa-edit"></i></a>
      				<a onclick="return confirm('Yakin Akan Meghapus Data ?')" class="btn btn-sm btn-danger" href="<?php echo base_url('admin/dataLayanan/deleteData/'.$p->id_layanan) ?>"><i class="fas fa-trash"></i></a>
      			</center>
        		</td>

        	</tr>
          <?php endforeach; ?>
        </tbody>
        
      </table>
    </div>
  </div>
</div>


</div>