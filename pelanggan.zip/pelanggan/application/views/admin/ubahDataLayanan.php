<div class="container-fluid">
  <div class="card shadow mb-4">
  <div class="card-header">
    <b>Ubah Data Layanan</b>
  </div>

  <div class="card-body">
    <?php foreach ($layanan as $p): ?>
    <form method="POST" action="<?php echo base_url('admin/dataLayanan/updateDataAksi') ?>" class="row g-3 needs-validation" >
      <div class="col-md-3">
        <label>ID Layanan</label>

        <input type="text" name="id_layanan" class="form-control" readonly value="<?php echo $p->id_layanan ?>" size="30">
                <?php echo form_error('id_layanan', '<div class="text-small text-danger"></div>') ?>   
      </div>

      <div class="col-md-3">
        <label>Nama Layanan</label>    
        <input type="text" name="layanan" value="<?php echo set_value('layanan',$p->layanan); ?>" placeholder="Nama Layanan" class="form-control" size="30">
                <?php echo form_error('layanan', '<div class="text-small text-danger"></div>') ?>
      </div>

      <div class="col-md-3">
        <label>Tarif Rp.</label>    
        <input type="number" name="tarif" value="<?php echo set_value('tarif',$p->tarif); ?>" placeholder="Rp. " class="form-control" size="30">
                <?php echo form_error('tarif', '<div class="text-small text-danger"></div>') ?>
      </div>

      <div class="mx-auto my-auto">
        <button type="submit" class="btn btn-info">Simpan</button>
        <a class="btn btn-warning mx-3" href="<?php echo base_url('admin/dataLayanan') ?>">Batal</a>
      </div>

    </form>
    <?php endforeach; ?>
  </div>
</div>
</div>