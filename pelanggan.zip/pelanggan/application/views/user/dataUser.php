
<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h5 class="h5 mb-0 text-gray-800"><?php echo $title ?></h5>
  </div>

<div class="card mb-4">
  <div class="card-body">
    <div class="row">
<?php foreach ($pengguna as $p) { ?>
    
      <div class="col-xl-6">
        <form method="POST" class="form-inline" action="<?php echo base_url('user/dataUser/updateDataAksi') ?>" enctype="multipart/form-data">
        <div class="container">

          <div class="row mb-3">
            <div class="col-4">
              <label>Nama Pengguna</label>
            </div>
            <div class="col">
              <input type="text" name="iduser" hidden class="form-control" value="<?php echo set_value('iduser',$p->iduser); ?>" size="30">
              <input type="text" name="nama" placeholder="Masukan Nama User" class="form-control" value="<?php echo set_value('nama',$p->nama); ?>" size="30">
              <?php echo form_error('nama', '<div class="text-small text-danger"></div>') ?>
            </div>
          </div>

          <div class="row mb-3">
            <div class="col-4">
              <label>Username</label>
            </div>
            <div class="col">
              <input type="text" readonly name="username" class="form-control" placeholder="Username untuk login" value="<?php echo set_value('username',$p->username); ?>" size="30">
              <?php echo form_error('username', '<div class="text-small text-danger"></div>') ?>
            </div>
          </div>

          <div class="row mb-3">
            <div class="col-4">
              <label>Ubah Password</label>
            </div>
            <div class="col">
              <input type="password" name="password" placeholder="Biarkan Kosong Jika tidak diubah" class="form-control form-password" value="<?php echo set_value('password'); ?>" size="30">
              <?php echo form_error('password', '<div class="text-small text-danger"></div>') ?>
              <input type="checkbox" class="form-checkbox"> Show password
            </div>
          </div>

          <div class="row mb-3">
            <div class="col-4">
              <label>Photo</label>
            </div>
            <div class="col">
              <input type="file" name="photo" class="form-control">
            <?php echo form_error('photo', '<div class="text-small text-danger"></div>') ?>
            </div>
          </div>

          <div class="row mb-3 justify-content-center">
              <div class="col-4">
                <button type="submit" class="btn btn-success">Simpan</button>
              </div>
            </div>



        </div>
        </form>
      </div>
    


      <div class="col-xl-6">
        <div class="container">
          <div class="row justify-content-center">
            <div class="text-center">

              <img src="<?php echo base_url().'assets/photo/'.$p->photo ?>" class="rounded mx-auto d-block img-thumbnail" alt="Profile">
            </div>
          </div>
        </div>
      </div>

    </div>



    

<?php } ?>
  </div>
</div>
</div>



</div>
<!-- End of Main Content -->

<script type="text/javascript">
  $(document).ready(function(){   
    $('.form-checkbox').click(function(){
      if($(this).is(':checked')){
        $('.form-password').attr('type','text');
      }else{
        $('.form-password').attr('type','password');
      }
    });
  });
</script>