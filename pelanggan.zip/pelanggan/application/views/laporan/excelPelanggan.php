
<h2> Laporan Data Pelanggan</h2>
<h2>MELDINA NETWORK</h2>
<h4>Periode : <?php echo date('F d Y',strtotime($tgla)) ?> s.d <?php echo date('F d Y',strtotime($tgln)) ?></h4>
<table>
    <tr>
        <td>Jenis Layanan</td>
        <td>:</td>
        <td><?php echo $poli ?></td>
    </tr>
    <?php 
        $cek   = "";
        if ($faskes==1) {
          $cek = "Aktif";
        }elseif ($faskes==2) {
          $cek = "Menunggu Pemasangan";
        }elseif ($faskes==3){
          $cek = "Diputus";
        }
     ?>
    <tr>
        <td>Status</td>
        <td>:</td>
        <td><?php echo $cek ?></td>
    </tr>
    
</table>
<table border="1" cellpadding="8">
<thead>
    <tr>
      <th>No</th>
      <th>ID Pelanggan</th>
      <th>Nama Pelanggan</th>
      <th>Alamat</th>
      <th>No HP</th>
      <th>Tanggal Daftar</th>
      <th>Layanan</th>
      <th>Status</th>
    </tr>
</thead>
  <tbody>
      <?php $no=1; foreach($datapelanggan as $a) : 
        $status = $a->status;
        $stat   = "";
        if ($status==1) {
          $stat = "Aktif";
        }elseif ($status==2) {
          $stat = "Menunggu Pemasangan";
        }elseif ($status==3) {
          $stat = "Diputuskan";
        }

         ?>
    <tr>
          
          <td><?php echo $no++ ?></td>
          <td><?php echo $a->id_pelanggan ?></td>
          <td><?php echo $a->nama_pelanggan ?></td>
          <td><?php echo $a->alamat ?></td>
          <td><?php echo $a->no_hp ?></td>
          <td><?php echo date('m-d-Y',strtotime($a->tgl_daftar)) ?></td>
          <td><?php echo $a->nlayanan ?></td>
          <td><?php echo $stat ?></td>
    </tr>
      <?php endforeach; ?>
  </tbody>
  <?php $jml_data = count($datapelanggan); ?>
  <tfoot>
      <tr>
          <td style="text-align: right;" colspan="6"><b>Jumlah Pelanggan</b></td>
          <td style="text-align: center;"><b><?php echo $jml_data ?> titik</b></td>
      </tr>
  </tfoot>
</table>