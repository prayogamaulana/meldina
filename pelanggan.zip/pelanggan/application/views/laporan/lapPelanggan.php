<div class="container-fluid">
	<div class="card mb-3">
		<div class="card-header bg-info text-white">
			Laporan Data Customer
		</div>
		<div class="card-body">
			<div class="container">
				<form>
				<div class="row">
					<div class="col-xl-2">
						<label for="tglawal">Dari Tanggal</label>
						<input type="date" class="form-control " id="tglawal" OnChange="tampiltgla()" name="tglawal" placeholder="Dari Tanggal">
					</div>
					<div class="col-xl-2">
						<label for="tglakhir">Sampai Tanggal</label>
						<input type="date" class="form-control " id="tglakhir" OnChange="tampiltgln()" name="tglakhir" placeholder="Sampai Tanggal">
					</div>
					<div class="col-xl-2">
						<label for="fjfas">By Status</label>
						<select name="fjfas" class="form-control" id="fjfas" OnChange="tampiljenis()">
							<option value="" <?php echo  set_select('fjfas', '', TRUE); ?>>--Pilih Status--</option>
							<option value="1">Aktif</option>
							<option value="2">Menunggu</option>
							<option value="3">Diputus</option>
						</select>
					</div>
					<div class="col-xl-3">
						<label for="fpoli">By Jenis Layanan</label>
						<select name="fpoli" id="fpoli" class="form-control" OnChange="tampilpoli()">
							<option value="" <?php echo  set_select('id_layanan', '', TRUE); ?>>--Pilih Jenis--</option>
							<?php foreach($layanan as $d) : ?>
							<option value="<?php echo $d->id_layanan ?>" <?php echo  set_select('id_layanan', $d->id_layanan); ?>><?php echo $d->id_layanan ." - ". $d->layanan ?></option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="col-xl-3">
    <label for="fdaerah">Cetak Daerah</label>
    <select name="fdaerah" id="fdaerah" class="form-control" OnChange="tampildaerah()">
        <option value="" <?php echo  set_select('id_daerah', '', TRUE); ?>>--Pilih Daerah--</option>
        <?php foreach($daerah as $d) : ?>
        <option value="<?php echo $d->id_daerah ?>" <?php echo  set_select('id_daerah', $d->id_daerah); ?>><?php echo $d->id_daerah ." - ". $d->daerah ?></option>
        <?php endforeach; ?>
    </select>
</div>
<input type="hidden" class="form-control form-control-sm" id="cetak_daerah" name="cetak_daerah">

					<div class="col text-right">
						<button type="submit" class="btn btn-info mt-4" title="Lihat & Tampilkan Data Pengunjung"><i class="fa fa-eye"></i> Lihat</button>

					</div>
				</form>
					<div class="col text-right">
						<form method="POST" action="<?php echo base_url('laporan/lapPelanggan/printPelanggan') ?>">

						<input type="text" hidden class="form-control form-control-sm" id="tgla" name="tgla">
						<input type="text" hidden class="form-control form-control-sm" id="tgln" name="tgln">
						<input type="text" hidden class="form-control form-control-sm" id="faskes" name="faskes">
						<input type="text" hidden class="form-control form-control-sm" id="poli" name="poli">

						<button id="cetak" type="submit" class="btn btn-danger mt-4" target='_blank' title="Cetak PDF Data Pengunjung"><i class="fas fa-print"></i> Cetak</button>
						</form>
					</div>
					<div class="col text-left">
						<form method="POST" action="<?php echo base_url('laporan/lapPelanggan/export') ?>">

						<input type="text" hidden class="form-control form-control-sm" id="tgla1" name="tgla1">
						<input type="text" hidden class="form-control form-control-sm" id="tgln1" name="tgln1">
						<input type="text" hidden class="form-control form-control-sm" id="faskes1" name="faskes1">
						<input type="text" hidden class="form-control form-control-sm" id="poli1" name="poli1">

						<button id="export" type="submit" class="btn btn-success mt-4" target='_blank' title="Export Excel Data Pengunjung"><i class="fas fa-file-excel"></i> Export</button>
						</form>
					</div>
					
					
				</div>
				

				<div class="row text-right mt-3">
						<div class="col">
						
							
							
							
							<!-- <a class="btn btn-warning mr-5" href="<?php echo base_url('admin/dataBeliObat') ?>">Cancle</a> -->
							<!-- <a id="cetakData" name="cetakData" class="btn btn-sm btn-success btn-flat" href="#" title="Cetak Data">
								<i class="fa fa-print"></i>
							</a> -->
						</div>


				</div>
			</div>
		</div>
	</div>

	<?php 
		$tglawal = "";
		$tglakhir = "";
		$jenis = "";
		$poli = "";
		if((isset($_GET['tglawal']) && $_GET['tglawal']!='') && (isset($_GET['tglakhir']) && $_GET['tglakhir']!='')){
			$tglawal = $_GET['tglawal'];
			$tglakhir = $_GET['tglakhir'];
		}else{
			$hariini = date('d-m-Y');
			$tglawal = $hariini;
			$tglakhir = $hariini;
		}
		if((isset($_GET['fjfas']) && $_GET['fjfas']!='')){
			$jenis = $_GET['fjfas'];
		}
		if((isset($_GET['fpoli']) && $_GET['fpoli']!='')){
			$poli = $_GET['fpoli'];
		}

		$jml_data = count($datapelanggan);

	 ?>

	<div class="alert alert-info">
		Menampilkan <span class="font-weight-bold"><?php echo $jml_data ?></span> Data Pelanggan Dari Tanggal : <span class="font-weight-bold"><?php echo date('d-m-Y',strtotime($tglawal)) ?></span> s.d <span class="font-weight-bold"><?php echo date('d-m-Y',strtotime($tglakhir)) ?></span> | Status : <span class="font-weight-bold"><?php echo $jenis ?></span> |Jenis Layanan : <span class="font-weight-bold"><?php echo $poli ?></span>
	</div>

	


	<div class="card shadow mb-4">
	  <div class="card-body">
	    <div class="table-responsive">
	    	<?php 
	if($jml_data > 0) {	 ?>
	      <table class="table table-bordered duatabel table-sm" id="dataTable">
	        <thead>
	      	 <tr>
	        		<th class="text-center">No</th>
		            <th class="text-center">ID Pelanggan</th>
		            <th class="text-center">Nama</th>
		            <th class="text-center">Alamat</th>
		            <th class="text-center">No HP</th>
		            <th class="text-center">Tgl Daftar</th>
		            <th class="text-center">Layanan</th>
		            <th class="text-center">Status</th>
	        	</tr>
	        </thead>
	        	
	        <tbody>
	        	<tr>
	        		<?php $no=1; $saldo=0; foreach($datapelanggan as $p) : 
	        			$status = $p->status;
	        		?>
	        		
	        			<td><?php echo $no++ ?></td>
		        		<td><?php echo $p->id_pelanggan ?></td>
			            <td><?php echo $p->nama_pelanggan ?></td>
			            <td><?php echo $p->alamat ?></td>
			            <td><?php echo $p->no_hp ?></td>
			            <td><?php echo date('d-m-Y',strtotime($p->tgl_daftar)) ?></td>
			            <td><?php echo $p->nlayanan ?></td>
	        			<td> <center>
			              <?php if($status==1) { ?>
			              <span class="badge badge-success"><i class="fas fa-check-circle"></i> Aktif</span>
			              <?php }elseif($status==2){ ?>
			                <span class="badge badge-warning"><i class="fas fa-info-circle"></i> Menunggu Tindakan</span>
			              <?php } else { ?>
			                <span class="badge badge-danger"><i class="fas fa-close-circle"></i>Diputus</span>
			              <?php } ?> </center></td>
	        	</tr>
	        	<?php endforeach; ?>
	        </tbody>
	        <tfoot>
	        	<tr>
	        		<td></td>
	        	</tr>
	        </tfoot>
		    </table>
		<?php }else{?>
			<span class="badge badge-danger"><i class="fas fa-info-circle"></i>Data Masih kosong</span>
		<?php } ?>
		</div>
		</div>
	</div>
</div>



<script>
	function tampiltgla(){
            var tanggala1 = document.getElementById("tglawal").value
            document.getElementById("tgla").value=tanggala1
            document.getElementById("tgla1").value=tanggala1
        }

    function tampiltgln(){
        var tanggaln1 = document.getElementById("tglakhir").value
        document.getElementById("tgln").value=tanggaln1
        document.getElementById("tgln1").value=tanggaln1
    }
    function tampiljenis(){
        var jenis1 = document.getElementById("fjfas").value
        document.getElementById("faskes").value=jenis1
        document.getElementById("faskes1").value=jenis1
    }

    function tampilpoli(){
        var poliklinik1 = document.getElementById("fpoli").value
        document.getElementById("poli").value=poliklinik1
        document.getElementById("poli1").value=poliklinik1
    }
    function tampildaerah(){
    var daerah = document.getElementById("fdaerah").value;
    document.getElementById("cetak_daerah").value = daerah;
}


	$(function() {

		$("#cetak").click(function() {
			var tanggala		= $("#tglawal").val();
			var tanggaln		= $("#tglakhir").val();
			var jenis			= $("#fjfas").val();
			var poliklinik		= $("#fpoli").val();


			if (tanggala == "") {
				swal("Opps !", "Tanggal Awal Harus Diisi", "warning");
				return false;
			}else if (tanggaln == "") {
				swal("Opps !", "Tanggal Akhir Harus Diisi", "warning");
				return false;
			}else {
				
	            swal("Good Job !", "Data Berhasil DiCetak", "success");
	            return true;
				
			}

		});

		$("#export").click(function() {
			var tanggala		= $("#tglawal").val();
			var tanggaln		= $("#tglakhir").val();
			var jenis			= $("#fjfas").val();
			var poliklinik		= $("#fpoli").val();


			if (tanggala == "") {
				swal("Opps !", "Tanggal Awal Harus Diisi", "warning");
				return false;
			}else if (tanggaln == "") {
				swal("Opps !", "Tanggal Akhir Harus Diisi", "warning");
				return false;
			}else {
				
	            swal("Good Job !", "Data Berhasil Diexport", "success");
	            return true;
				
			}

		});

	});
</script>