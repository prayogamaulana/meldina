<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title ?></title>
	<style>
        #table {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #table td, #table th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #table tr:nth-child(even){background-color: #f2f2f2;}

        #table tr:hover {background-color: #ddd;}

        #table th {
            padding-top: 10px;
            padding-bottom: 10px;
            text-align: center;
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>
<body>
	<div style="text-align:center">
        <h2>MELDINA NETWORK</h2>
        <p>Jl.Pendidikan Kp.Ciheulang Tonggoh Kec. Cibadak Kab. Sukabumi | Email : meldinanetwork@gmail.com Telp.: 083111170709</p>
        <hr>
        <h4>Periode : <?php echo date('d F Y',strtotime($tgla)) ?> s.d <?php echo date('d F Y',strtotime($tgln)) ?></h4>
    </div>
    <div>
        <table>
            <tr>
                <td>Jenis Layanan</td>
                <td>:</td>
                <td><?php echo $poli ?></td>
            </tr>
            <?php 
                $cek   = "";
                if ($faskes==1) {
                  $cek = "Aktif";
                }elseif ($faskes==2) {
                  $cek = "Menunggu Pemasangan";
                }elseif ($faskes==3){
                  $cek = "Diputus";
                }else{
                  $cek = "";  
                }
             ?>
            <tr>
                <td>Status</td>
                <td>:</td>
                <td><?php echo $cek ?></td>
            </tr>
            
        </table>
    </div>
    <table id="table" style="margin-top: 20px;">
        <thead>
        	<tr>
        		<th>No</th>
                <th>ID Pelanggan</th>
                <th>Nama Pelanggan</th>
                <th>Alamat</th>
                <th>No HP</th>
                <th>Tanggal Daftar</th>
                <th>Layanan</th>
                <th>Status</th>
        	</tr>
    	</thead>
        <tbody>
            <?php $no=1; foreach($datapelanggan as $a) : 
                $status = $a->status;
                $stat   = "";
                if ($status==1) {
                  $stat = "Aktif";
                }elseif ($status==2) {
                  $stat = "Menunggu Pemasangan";
                }elseif ($status==3) {
                  $stat = "Diputuskan";
                }

                 ?>
        	<tr>
                
                <td><?php echo $no++ ?></td>
                <td><?php echo $a->id_pelanggan ?></td>
                <td><?php echo $a->nama_pelanggan ?></td>
                <td><?php echo $a->alamat ?></td>
                <td><?php echo $a->no_hp ?></td>
                <td><?php echo date('d-m-Y',strtotime($a->tgl_daftar)) ?></td>
                <td><?php echo $a->nlayanan ?></td>
                <td><?php echo $stat ?></td>

            </tr>
            <?php endforeach; ?>
        </tbody>
        <?php $jml_data = count($datapelanggan); ?>
        <tfoot>
            <tr>
                <td style="text-align: right;" colspan="6"><b>Jumlah Pelanggan</b></td>
                <td style="text-align: center;"><b><?php echo $jml_data ?> Pelanggan</b></td>
            </tr>
        </tfoot>
    </table>
</body>
</html>