<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title ?></title>
	<style>
        #table {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #table td, #table th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #table tr:nth-child(even){background-color: #f2f2f2;}

        #table tr:hover {background-color: #ddd;}

        #table th {
            padding-top: 10px;
            padding-bottom: 10px;
            text-align: center;
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>
<body>
	<div style="text-align:center">
        <h2>MELDINA NETWORK</h2>
        <p>Jl.Pendidikan Kp.Ciheulang Tonggoh Rt 004 Rw 002 Kec. Cibadak Kab. Sukabumi | Email : meldinanetwork@gmail.com Telp.: 083111170709</p>
        <hr>
    </div>
    <div>
        <?php $no=1; foreach($pelanggan as $a) : 
                $status = $a->status;
                if ($status=="1") {
                  $stat = "Aktif";
                }elseif ($status=="2") {
                  $stat = "Menunggu Pemasangan";
                }elseif ($status=="3") {
                  $stat = "Diputuskan";
                }

                 ?>
        <h4>ID Pelanggan</h4>
        <p>: <?php echo $a->id_pelanggan ?></p>
        <h4>Nama Pelanggan</h4>
        <p>: <?php echo $a->nama_pelanggan ?></p>
        <h4>Nomor Telp.</h4>
        <p>: <?php echo $a->no_hp ?></p>
        <h4>Alamat</h4>
        <p>: <?php echo $a->alamat ?></p>
        <h4>Tanggal Daftar</h4>
        <p>: <?php echo date('d F Y',strtotime($a->tgl_daftar))  ?></p>
        <h4>Jenis Layanan</h4>
        <p>: <?php echo $a->nlayanan ?></p>
        <h4>Status : <?php echo $stat ?></h4>
        
            <?php endforeach; ?>
    </div>
</body>
</html>