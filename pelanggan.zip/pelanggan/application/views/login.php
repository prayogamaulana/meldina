

<body background="<?php echo base_url('assets/img/logo.png') ?>">

  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-6 p-5 d-none d-lg-block justify-content-center" style="background-color: whites;">
                <div class="row justify-content-center">
                  <img src="<?php echo base_url('assets/img/1.jpg') ?>" width="300">
                </div>
                <div class="text-center">
                  <hr>
                  <p class="copyright  mb-4"><?php echo "Copyright &copy; ". (int)date('Y')." | Prayoga Maulana Prastya Amd.Kom - Meldina Network" ; ?></p>
                </div>
              </div>
              <div class="col-lg-6 border-left">
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">SELAMAT DATANG DI</h1>
                    <hr>
                    <h1 class="h2 text-gray-900 mb-4"><B>MELDINA NETWORK</B><br><sup class="mt-2">SUKABUMI</sup></h1>

                  </div>
                  <?php echo $this->session->flashdata('pesan'); ?>
                  <form class="user" method="POST" action="<?php echo base_url('welcome/login') ?>">
                    <div class="form-group">
                      <input type="text" name="username" class="form-control form-control-user" placeholder="Masukan Username anda...">
                      <?php echo form_error('username', '<div class="text-small text-danger"></div>') ?>
                    </div>
                    <div class="form-group">
                      <input type="password" name="password" class="form-control form-control-user" placeholder="Masukan password Anda">
                      <?php echo form_error('password', '<div class="text-small text-danger"></div>') ?>
                    </div>
                    <hr>
                    <button type="submit" class="btn btn-info btn-user btn-block">Login</button>
                    
                  </form>
                  
                  
                </div>
                
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>
  
<!-- Bootstrap core JavaScript-->

  <script src="<?php echo base_url().'assets/vendor/jquery/jquery.min.js'?>"></script>
  
  <script src="<?php echo base_url().'assets/vendor/bootstrap/js/bootstrap.bundle.min.js'?>"></script>

  <!-- Core plugin JavaScript-->
  <script src="<?php echo base_url().'assets/vendor/jquery-easing/jquery.easing.min.js'?>"></script>


  <!-- Custom scripts for all pages-->
  <script src="<?php echo base_url().'assets/js/sb-admin-2.min.js'?>"></script>
  

  <!-- Page level plugins -->
  <script src="<?php echo base_url().'assets/vendor/chart.js/Chart.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/vendor/datatables/jquery.dataTables.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/vendor/datatables/dataTables.bootstrap4.min.js'?>"></script>

  <!-- Page level custom scripts -->
  <script src="<?php echo base_url().'assets/js/demo/datatables-demo.js'?>"></script>

  


</body>

</html>
