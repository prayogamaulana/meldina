
<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center mb-4">
    <h5 class="h5 mb-0 text-gray-800"><?php echo $title ?></h5>
  </div>

<div class="card mb-4">
	<div class="card-body">
		<form method="POST" class="form-inline" action="<?php echo base_url('regist/dataPelanggan/tambahDataAksi') ?>">
			<div class="container">
			  <div class="row">
			    <div class="col-lg-6">
			    	<div class="container">
			    	<div class="row mb-3">
			    		<div class="col-4">
							<label>ID Pelanggan</label>
						</div>
						<div class="col">
							<input type="text" name="id_pelanggan" class="form-control" readonly="readonly" value="<?php echo $kodeunik ?>" size="30">
							<?php echo form_error('id_pelanggan', '<div class="fw-lighter text-small text-danger"></div>') ?>
						</div>
					</div>

					<div class="row mb-3">
						<div class="col-4">
							<label>Nama Pelanggan</label>
						</div>
						<div class="col">
							<input type="text" name="nama_pelanggan" value="<?php echo set_value('nama_pelanggan'); ?>" placeholder="Nama Pelanggan" class="form-control" size="30">
							<?php echo form_error('nama_pelanggan', '<div class="text-small text-danger"></div>') ?>
						</div>
					</div>

					<div class="row mb-3">
						<div class="col-4">
							<label>Nomor Telp</label>
						</div>
						<div class="col">
							<input type="tel" name="no_hp" placeholder="Ex : 0857955*****" class="form-control" size="30" value="<?php echo set_value('no_hp'); ?>" maxlength="15">
							<?php echo form_error('no_hp', '<div class="text-small text-danger"></div>') ?>
						</div>
					</div>

					<div class="row mb-3">
						<div class="col-4">
							<label>Alamat</label>
						</div>
						<div class="col">
							<textarea name="alamat" value="<?php echo set_value('alamat'); ?>" placeholder="Alamat" class="form-control" size="30">
							<?php echo form_error('alamat', '<div class="text-small text-danger"></div>') ?>
							</textarea>
						</div>
					</div>

					<div class="row mb-3">
						<div class="col-4">
							<label>Tgl Daftar</label>
						</div>

						<div class="col">
							<input type="date" name="tgl_daftar" value="<?php echo set_value('tgl_daftar'); ?>" placeholder="Tanggal Lahir" class="form-control" >
							<?php echo form_error('tgl_daftar', '<div class="text-small text-danger"></div>') ?>
						</div>
						
					</div>

					<div class="row mb-3">
						<div class="col-4">
							<label>Layanan</label>
						</div>
						<div class="col">
							<select name="id_layanan" class="form-control">
								<option value="" <?php echo  set_select('id_layanan', '', TRUE); ?>>--Pilih Layanan--</option>
								<?php foreach($layanan as $d) : ?>
								<option value="<?php echo $d->id_layanan ?>" <?php echo  set_select('id_layanan', $d->id_layanan); ?>><?php echo $d->id_layanan ." - ". $d->layanan ?></option>
								<?php endforeach; ?>
							</select>
							<?php echo form_error('id_layanan', '<div class="text-small text-danger"></div>') ?>
						</div>
					</div>

					<div class="row justify-content-center">

						<a class="btn btn-warning mx-3" href="<?php echo base_url('regist/dataPelanggan') ?>">Cancle</a>
						<button type="submit" class="btn btn-success">Simpan</button>

					</div>

				</div>

					<!-- end div col -->
			    </div>



				

			    </div>

			  </div>
			</div>
			
		</form>
	</div>
</div>



</div>
<!-- End of Main Content -->