<div class="container-fluid">
	<div class="card mb-3">
		<div class="card-header bg-success text-white">
			Form Ubah Data Pendaftaran
		</div>
		<div class="card-body">
			<div class="container">

				<!-- row form regist -->
				<div class="row cols-2">
					<?php foreach ($regist as $a) : ?>	
					<!-- awal form registrasi -->
					<form method="POST" class="form-inline" action="<?php echo base_url('regist/Pendaftaran/updateDataAksi') ?>">
						<!-- col data pasien -->
						<div class="col-6">
							<div class="container">
																		
					    		<table>
					    			<tr>
					    				<td>No Pendaftaran</td>
					    				<td>:</td>
					    				<td><input type="text" class="form-control-plaintext" readonly name="FNO_REG" value="<?php echo set_value('FNO_REG',$a->FNO_REG); ?>"></td>
					    			</tr>
					    			<tr>
					    				<td>No RM</td>
					    				<td>:</td>
					    				<td><input type="text" class="form-control-plaintext" readonly name="FNO_RM" value="<?php echo $a->FNO_RM ?>"></td>
					    			</tr>
					    			<tr>
					    				<td>Nama Pasien</td>
					    				<td>:</td>
					    				<td><input type="text" class="form-control-plaintext" readonly name="FN_PASIEN" value="<?php echo $a->FN_PASIEN ?>"></td>
					    			</tr>
					    			<tr>
					    				<td>Tanggal Pendaftaran</td>
					    				<td>:</td>
					    				<td><input type="text" class="form-control-plaintext" readonly name="FTGL_REG" value="<?php echo $a->FTGL_REG ?>"></td>
					    			</tr>
					    		</table>
							</div>
						</div>

						<!-- col form regist -->
						<div class="col-6">
							<div class="container">
								<div class="row form-group form-inline mb-2">
									<div class="col">
										<label>Poliklinik</label>
									</div>
									<div class="col">
										<select name="FNO_POLI" class="form-control">
											<option value="" <?php echo ($a->FNO_POLI == "") ? 'selected' : '' ?>>--Pilih No Poli--</option>
											<?php foreach($poli as $pl) : ?>
											<option value="<?php echo $pl->FNO_POLI ?>" <?php echo ($a->FNO_POLI == "$pl->FNO_POLI") ? 'selected' : ''?>><?php echo $pl->FNO_POLI ." - ". $pl->FN_POLI ?></option>
											<?php endforeach; ?>
										</select> 
									</div>
								</div>
								<div class="row form-group form-inline mb-2">
									<div class="col">
										<label>Dokter</label>
									</div>
									<div class="col">
										<select name="FNO_DOKTER" class="form-control">
											<option value="" <?php echo ($a->FNO_DOKTER == "") ? 'selected' : '' ?>>--Pilih No Dokter--</option>
											<?php foreach($dokter as $dk) : ?>
											<option value="<?php echo $dk->FNO_DOKTER ?>" <?php echo ($a->FNO_DOKTER == "$dk->FNO_DOKTER") ? 'selected' : ''?>><?php echo $dk->FNO_DOKTER ." - ". $dk->FN_DOKTER ?></option>
											<?php endforeach; ?>
										</select>
										<?php echo form_error('FNO_DOKTER', '<div class="text-small text-danger"></div>') ?>
									</div>
								</div>
								<div class="row form-group form-inline mb-2">
									<div class="col">
										<label>Jenis Faskes</label>
									</div>
									<div class="col form-check form-check-inline">
										  <input class="form-check-input mx-2" type="radio" name="FJFAS" id="inlineRadio1" value="Umum" <?php echo ($a->FJFAS == "Umum") ? 'checked' : ''?>>Umum
										  <input class="form-check-input mx-2" type="radio" name="FJFAS" id="inlineRadio2" value="Asuransi" <?php echo ($a->FJFAS == "Asuransi") ? 'checked' : ''?>>Asuransi
										  <input class="form-check-input mx-2" type="radio" name="FJFAS" id="inlineRadio2" value="BPJS" <?php echo ($a->FJFAS == "BPJS") ? 'checked' : ''?>>BPJS
									</div>
									<input type="text" name="FUSER" hidden="hidden"  value="<?php echo $this->session->userdata('nama') ?>" class="form-control">
									<input type="text" name="FCOM" hidden="hidden" class="form-control" value="<?php echo $fcom ?>">
								</div>

								<div class="row align-middle">
									<div class="col">
										<div class="d-flex flex-row-reverse">
											<div class="p-2">
												<button type="submit" class="btn btn-success">Ubah</button>
											</div>
										</div> 	
									</div>
								</div>

							</div>
						</div>
					</form>
					<!-- akhir form registrasi -->	
					<?php endforeach; ?>
				</div>
				<!-- akhir row form regist -->
			</div>
			<!-- akhir container -->
		</div>
		<!-- akhir card body -->
	</div>
	<!-- akhir card -->
</div>