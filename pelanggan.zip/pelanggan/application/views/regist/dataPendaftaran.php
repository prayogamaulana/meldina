<div class="container-fluid">
	<div class="card mb-3">
		<div class="card-header bg-success text-white">
			Form Pendaftaran
		</div>
		<div class="card-body">
			<div class="container">
				<!-- row cari pasien -->
				<div class="row">
					<div class="col">
						<div class="form-group form-inline">
							<div class="navbar-form navbar-right">
								<?php echo form_open('regist/Pendaftaran') ?>
					    		<input type="text" id="keyword" name="keyword" class="form-control" autofocus title="Cari Nama, No RM, NIK atau Tanggal Lahir" autocomplete="off" placeholder="Cari Pasien">
					    		<button type="submit" class="btn btn-success">Cari</button>
					    		<?php echo form_close() ?>
							</div>
						</div>
					</div>
				</div>
				<?php echo $this->session->flashdata('pesan'); ?>

				<!-- row form regist -->
				<div class="row cols-2">
					<!-- awal form registrasi -->
					<form method="POST" class="form-inline" action="<?php echo base_url('regist/Pendaftaran/tambahDataAksi') ?>">
						<!-- col data pasien -->
						<div class="col-xl-6">
							<div class="container">
								<?php 
					    		if((isset($_POST['keyword']) && $_POST['keyword']!='')){
					    			 $jml_data = count($pasien);
					    			 if($jml_data > 0) {
					    			foreach ($pasien as $a) :
					    			$tanggal = new DateTime($a->FTGL_LAHIR);
						              $today = new DateTime('today');
						              $y = $today->diff($tanggal)->y;
						             
											 ?>
											 <div class="alert alert-info alert-dismissible fade show" role="alert">
											  <strong><span class="font-weight-bold"><?php echo $jml_data ?></span> Pasien Ditemukan !</strong>
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
											</div>
											
					    		<table>
					    			<tr>
					    				<td>No RM</td>
					    				<td>:</td>
					    				<td><input type="text" class="form-control-plaintext" readonly name="FNO_RM" value="<?php echo $a->FNO_RM ?>">
					    					<?php echo form_error('FNO_RM', '<div class="text-small text-danger"></div>') ?>
										<input type="text" class="form-control-plaintext" hidden name="FNO_REG" value="<?php echo $noregist ?>"></td>
					    			</tr>
					    			<tr>
					    				<td>NIK / ID</td>
					    				<td>:</td>
					    				<td><input type="text" class="form-control-plaintext" readonly name="FNIK" value="<?php echo $a->FNIK ?>"></td>
					    				<?php echo form_error('FNIK', '<div class="text-small text-danger"></div>') ?>
					    			</tr>
					    			<tr>
					    				<td>Nama Pasien</td>
					    				<td>:</td>
					    				<td><input type="text" class="form-control-plaintext" readonly name="FN_PASIEN" value="<?php echo $a->FN_PASIEN ?>"></td>
					    			</tr>
					    			<tr>
					    				<td>Jenis Kelamin / Usia</td>
					    				<td>:</td>
					    				<td><input type="text" class="form-control-plaintext" readonly name="FKELAMIN" value="<?php echo $a->FKELAMIN." / ".$y ?>"></td>
					    			</tr>
					    			<tr>
					    				<td>Tempat, Tgl Lahir</td>
					    				<td>:</td>
					    				<td><input type="text" class="form-control-plaintext" readonly name="FTGL_LAHIR" value="<?php echo $a->FTMP_LAHIR.", ".$a->FTGL_LAHIR ?>">
										<input type="text" name="FUSER" hidden="hidden"  value="<?php echo $this->session->userdata('nama') ?>" class="form-control">
										<input type="text" name="FCOM" hidden="hidden" class="form-control" value="<?php echo $fcom ?>">
										<input type="text" name="FSTAT" hidden="hidden" class="form-control" value="1"></td>
					    			</tr>
					    		</table>
								<?php endforeach; }else{ ?>
									<div class="alert alert-danger">
										Pasien Tidak Ditemukan/ Belum Terdaftar! Periksa kembali keyword Anda
									</div>
								<?php }  }else{?>
									<span class="badge badge-warning"><i class="fas fa-info-circle"></i>Data Masih kosong, silahkan cari data Pasien</span>
								<?php } ?>
							</div>
						</div>

						<!-- col form regist -->
						<div class="col-xl-6">
							<div class="container">
								<div class="row form-group form-inline mb-2">
									<div class="col">
										<label>Poliklinik</label>
									</div>
									<div class="col">
										<select name="FNO_POLI" class="form-control">
											<option value="" <?php echo  set_select('FNO_POLI', '', TRUE); ?>>--Pilih No Poli--</option>
											<?php foreach($poli as $d) : ?>
											<option value="<?php echo $d->FNO_POLI ?>" <?php echo  set_select('FNO_POLI', $d->FNO_POLI); ?>><?php echo $d->FNO_POLI ." - ". $d->FN_POLI ?></option>
											
											
											<?php endforeach; ?>
										</select>
										<?php echo form_error('FNO_POLI', '<div class="text-small text-danger"></div>') ?>
									</div>
								</div>
								<div class="row form-group form-inline mb-2">
									<div class="col">
										<label>Dokter</label>
									</div>
									<div class="col">
										<select name="FNO_DOKTER" class="form-control">
											<option value="" <?php echo  set_select('FNO_DOKTER', '', TRUE); ?>>--Pilih No Dokter--</option>
											<?php foreach($dokter as $d) : ?>
											<option value="<?php echo $d->FNO_DOKTER ?>" <?php echo  set_select('FNO_DOKTER', $d->FNO_DOKTER); ?>><?php echo $d->FNO_DOKTER ." - ". $d->FN_DOKTER ?></option>
											<?php endforeach; ?>
											
										</select>
										<?php echo form_error('FNO_DOKTER', '<div class="text-small text-danger"></div>') ?>
									</div>
								</div>
								<div class="row form-group form-inline mb-2">
									<div class="col">
										<label>Jenis Faskes</label>
									</div>
									<div class="col form-check form-check-inline">
										  <input class="form-check-input mx-2" type="radio" name="FJFAS" id="inlineRadio1" value="Umum">Umum
										  <input class="form-check-input mx-2" type="radio" name="FJFAS" id="inlineRadio2" value="Asuransi">Asuransi
										  <input class="form-check-input mx-2" type="radio" name="FJFAS" id="inlineRadio2" value="BPJS">BPJS
									</div>

								</div>
								<?php echo form_error('FJFAS', '<div class="text-small text-danger"></div>') ?>

								<div class="row align-middle">
									<div class="col">
										<div class="d-flex flex-row-reverse">
											<div class="p-2">
												<button type="submit" class="btn btn-success">Daftar</button>
											</div>
										</div> 	
									</div>
								</div>

							</div>
						</div>
					</form>
					<!-- akhir form registrasi -->	
				</div>
				<!-- akhir row form regist -->
			</div>
			<!-- akhir container -->
		</div>
		<!-- akhir card body -->
	</div>
	<!-- akhir card -->

	<!-- Awal Tabel Data Registrasi -->
	<div class="card shadow mb-4">
		<div class="card-header bg-info text-white">
			Data Pendaftar
		</div>
		<div class="card-body">
			
			<?php 
			$jml_data = count($regist);
			if($jml_data > 0) {	 ?>
			<div class="table-responsive">
				<table class="table table-bordered duatabel" id="dataTable">
					<thead>
						<tr>
							<th class="text-center">No</th>
			        		<th class="text-center">No Registrasi</th>
			        		<th class="text-center">No RM</th>
			        		<th class="text-center">Nama Pasien</th>
			        		<th class="text-center">Dokter</th>
			        		<th class="text-center">Poli</th>
			        		<th class="text-center">Faskes</th>
			        		<th class="text-center">Action</th>
						</tr>
					</thead>
					<tbody>
						<?php $no=1; foreach($regist as $r) : ?>
						<tr>
							
							<td><?php echo $no++ ?></td>
		        			<td><?php echo $r->FNO_REG ?></td>
		        			<td><?php echo $r->FNO_RM ?></td>
		        			<td><?php echo $r->FN_PASIEN ?></td>
		        			<td><?php echo $r->dokter ?></td>
		        			<td><?php echo $r->poli ?></td>
		        			<td><?php echo $r->FJFAS ?></td>
		        			<td>
		        				<a class="btn btn-sm btn-info" title="Cetak Kartu Antrian" target="_blank" href="<?php echo base_url('regist/Pendaftaran/cetakRegist/'.$r->FNO_REG) ?>"><i class="fas fa-print"></i></a>
		        				<a class="btn btn-sm btn-warning" title="Ubah Data" href="<?php echo base_url('regist/Pendaftaran/updateData/'.$r->FNO_REG) ?>"><i class="fas fa-edit"></i></a>
		        			</td>
		        			
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<?php }else{?>
			<span class="badge badge-danger"><i class="fas fa-info-circle"></i>Pendaftar Hari ini Masih kosong, silahkan input data Registrasi di atas !</span>
			<?php } ?>
		</div>
	</div>
	<!-- Akhir Tabel Data Registrasi -->

</div>
<!-- akhir container -->


<div class="modal fade" id="modal-pasien">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Pilih Pasien</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>

			<div class="modal-body table-responsive">
				<table class="table table-sm table-bordered table-striped duatabel" id="dataTable" style="width: 100%">
			        <thead>
			        	<tr>
			        		<th class="text-center">No RM</th>
			        		<th class="text-center">Nama Pasien</th>
			        		<th class="text-center">JK</th>
				            <th class="text-center">Tanggal Lahir</th>
				            <th class="text-center">Usia</th>
				            <th class="text-center">Alamat</th>
			        		<th class="text-center">Action</th>
			        	</tr>
			        </thead>
			        <tbody>
			           <?php 
			            foreach ($pasiencari as $p) : 
			              $tanggal = new DateTime($p->FTGL_LAHIR);
			              $today = new DateTime('today');
			              $y = $today->diff($tanggal)->y;
			              ?>
			      		<tr>
			      			<td><?php echo $p->FNO_RM ?></td>
			            	<td><?php echo $p->FN_PASIEN ?></td>
			      			<td><?php echo $p->FKELAMIN ?></td>
			      			<td><?php echo $p->FTGL_LAHIR ?></td>
				            <td><?php echo $y ?></td>
				            <td><?php echo $p->FJALAN ?></td>
				            <td class="text-center">
		      					<a href="#" class="btn add_cart_pasien btn-sm btn-info text-white" title="Pilih Pasien" id="pilih"
		      					 data-rm="<?=$p->FNO_RM ?>">
		      					<i class="fas fa-check"></i>
		      					</a>	
			      			</td>
			      		</tr>
			  	 <?php endforeach; ?>
			     </tbody>
			  </table>

			</div>
		</div>
	</div>
</div>

<script>
	$(function() {

		// Memanggil Modal Data Tarif
		$("#keyword").click(function() {
			$("#modal-pasien").modal("show");
		});

		// Menambahka Kode text box
		$(".add_cart_pasien").click(function() {
			var no_rm    = $(this).data("rm");
            $('#keyword').val(no_rm);
            $('#modal-pasien').modal('hide');
		});

		$(document).ready(function() {
		    $('table.duatabel').DataTable();
		} );

	});
</script>