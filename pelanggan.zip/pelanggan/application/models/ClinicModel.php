<?php 

class ClinicModel extends CI_model{

	public function get_data($table){
		return $this->db->get($table);
	}

	public function get_data_dokter(){
		$this->db->select('*');
		$this->db->from('t00_m_dokter');
		$tampil = $this->db->get()->result();

		return $tampil;
	}

	public function ambil_tempo(){
		$this->db->select('*');
		$this->db->from('tempo_beli');
		$tampil = $this->db->get()->result_array();

		return $tampil;
	}

	public function get_keyword($keyword){
		$this->db->select('*');
		$this->db->from('t00_m_pasien');
		$this->db->like('FNO_RM', $keyword);
		$this->db->or_like('FNIK', $keyword);
		$this->db->or_like('FN_PASIEN', $keyword);
		$this->db->or_like('date(FTGL_LAHIR)', $keyword);
		$tampil = $this->db->get()->result();

		return $tampil;
	}

	public function get_cetak_head($id){
      return $query = $this->db->query("SELECT t10_bayar_h.*, t00_m_pasien.FN_PASIEN,t00_m_poli.FN_POLI, t00_m_dokter.FN_DOKTER
			FROM t10_bayar_h
			INNER JOIN t00_m_pasien ON t10_bayar_h.FNO_RM=t00_m_pasien.FNO_RM
			INNER JOIN t00_m_poli ON t10_bayar_h.FNO_POLI=t00_m_poli.FNO_POLI
			INNER JOIN t00_m_dokter ON  t10_bayar_h.FNO_DOKTER=t00_m_dokter.FNO_DOKTER
			WHERE t10_bayar_h.FNO_BAYAR='$id' ORDER BY t10_bayar_h.FNO_BAYAR ASC ")->row();
   	}

   	public function get_cetak_tarif($id)
   	{
   		return $tarif = $this->db->query("SELECT t10_bayar_tarif.*, t00_m_tarif.FN_TARIF FROM t10_bayar_tarif
			INNER JOIN t00_m_tarif ON t10_bayar_tarif.FNO_TARIF=t00_m_tarif.FNO_TARIF
			WHERE t10_bayar_tarif.FNO_BAYAR='$id' ORDER BY t10_bayar_tarif.FNO_TARIF ASC ")->result_array();
   	}

   	public function get_cetak_obat($id)
   	{
   		return $obat = $this->db->query("SELECT t10_bayar_obat.*, t00_m_obat.FN_OBAT
			FROM t10_bayar_obat
			INNER JOIN t00_m_obat ON t10_bayar_obat.FNO_OBAT=t00_m_obat.FNO_OBAT
			WHERE t10_bayar_obat.FNO_BAYAR='$id' ORDER BY t10_bayar_obat.FNO_OBAT ASC ")->result_array();
   	}


	//kode Reka Medis (RM)
	public function buat_kode()   {

		$thn = date('ym');

		$q = $this->db->query("SELECT MAX(RIGHT(id_pelanggan,3)) AS kd_max FROM tb_pelanggan WHERE MID(id_pelanggan,3,4)=$thn");
        $kd = "";
        if($q->num_rows()>0){
            foreach($q->result() as $k){
                $tmp = ((int)$k->kd_max)+1;
                $kd = sprintf("%03s", $tmp);
            }
        }else{
            $kd = "001";
        }
        $kodejadi = "P-".$thn."-".$kd;
        return $kodejadi;
	}

	//Kode Nomor Dokter
	public function no_dokter()   {

		  $this->db->select('RIGHT(t00_m_dokter.FNO_DOKTER,3) as kode', FALSE);
		  $this->db->order_by('FNO_DOKTER','DESC');    
		  $this->db->limit(1);    
		  $query = $this->db->get('t00_m_dokter');      //cek dulu apakah ada sudah ada kode di tabel.    
		  if($query->num_rows() <> 0){      
		   //jika kode ternyata sudah ada.      
		   $data = $query->row();      
		   $kode = intval($data->kode) + 1;    
		  }
		  else {      
		   //jika kode belum ada      
		   $kode = 1;    
		  }

		  $kodemax = str_pad($kode, 3, "0", STR_PAD_LEFT); // angka 4 menunjukkan jumlah digit angka 0
		  $kodejadi = "D".$kodemax;    // hasilnya ODJ-9921-0001 dst.
		  return $kodejadi;  
	}

	//Kode Nomor Poli
	public function no_poli()   {

		$q = $this->db->query("SELECT MAX(RIGHT(FNO_POLI,1)) AS kd_max FROM t00_m_poli");
        $kd = "";
        if($q->num_rows()>0){
            foreach($q->result() as $k){
                $tmp = ((int)$k->kd_max)+1;
                $kd = sprintf("%01s", $tmp);
            }
        }else{
            $kd = "1";
        }
        $kodejadi = "P".$kd;
        return $kodejadi;
	}

	//Kode Nomor Supplier
	public function kode_sup()   {

		  $this->db->select('RIGHT(t00_m_supplier.FK_SUP,2) as kode', FALSE);
		  $this->db->order_by('FK_SUP','DESC');    
		  $this->db->limit(1);    
		  $query = $this->db->get('t00_m_supplier');      //cek dulu apakah ada sudah ada kode di tabel.    
		  if($query->num_rows() <> 0){      
		   //jika kode ternyata sudah ada.      
		   $data = $query->row();      
		   $kode = intval($data->kode) + 1;    
		  }
		  else {      
		   //jika kode belum ada      
		   $kode = 1;    
		  }

		  $kodemax = str_pad($kode, 2, "0", STR_PAD_LEFT); // angka 4 menunjukkan jumlah digit angka 0
		  $kodejadi = "S".$kodemax;    // hasilnya ODJ-9921-0001 dst.
		  return $kodejadi;  
	}

	//Kode Nomor Tarif
	public function no_tarif()   {

		$q = $this->db->query("SELECT MAX(RIGHT(FNO_TARIF,3)) AS kd_max FROM t00_m_tarif");
        $kd = "";
        if($q->num_rows()>0){
            foreach($q->result() as $k){
                $tmp = ((int)$k->kd_max)+1;
                $kd = sprintf("%03s", $tmp);
            }
        }else{
            $kd = "001";
        }
        $kodejadi = "TF".$kd;
        return $kodejadi;
	}

	//Kode Nomor Tarif
	public function no_obat()   {

		$q = $this->db->query("SELECT MAX(RIGHT(FNO_OBAT,4)) AS kd_max FROM t00_m_obat");
        $kd = "";
        if($q->num_rows()>0){
            foreach($q->result() as $k){
                $tmp = ((int)$k->kd_max)+1;
                $kd = sprintf("%04s", $tmp);
            }
        }else{
            $kd = "0001";
        }
        $kodejadi = "C".$kd;
        return $kodejadi;
	}

	
	//Kode Nomor Registrasi
	public function no_regist()   {

		$thn = date('ymd');

		$q = $this->db->query("SELECT MAX(RIGHT(FNO_REG,3)) AS kd_max FROM t10_t_registrasi WHERE MID(FNO_REG,3,6)=$thn");
        $kd = "";
        if($q->num_rows()>0){
            foreach($q->result() as $k){
                $tmp = ((int)$k->kd_max)+1;
                $kd = sprintf("%03s", $tmp);
            }
        }else{
            $kd = "001";
        }
        $kodejadi = "R.".$thn.".".$kd;
        return $kodejadi;
    }

    //Kode Nomor Bayar
    public function no_bayar()   {

		$thn = date('ym');

		$q = $this->db->query("SELECT MAX(RIGHT(FNO_BAYAR,4)) AS kd_max FROM t10_bayar_h WHERE MID(FNO_BAYAR,2,4)=$thn");
        $kd = "";
        if($q->num_rows()>0){
            foreach($q->result() as $k){
                $tmp = ((int)$k->kd_max)+1;
                $kd = sprintf("%04s", $tmp);
            }
        }else{
            $kd = "0001";
        }
        $kodejadi = "B".$thn.".".$kd;
        return $kodejadi;
    }

    //Kode Nomor Beli Obat
	public function no_beli()   {

		$thn = date('ym');

		$q = $this->db->query("SELECT MAX(RIGHT(FNO_BELI,3)) AS kd_max FROM t10_beli_h WHERE LEFT(FNO_BELI,4)=$thn");
        $kd = "";
        if($q->num_rows()>0){
            foreach($q->result() as $k){
                $tmp = ((int)$k->kd_max)+1;
                $kd = sprintf("%03s", $tmp);
            }
        }else{
            $kd = "001";
        }
        $kodejadi = $thn.$kd;
        return $kodejadi;
    }

    //Kode Nomor Periode
	public function no_periode()   {

		$thn = date('Ym');
        $kodejadi = $thn;
        return $kodejadi;
    }

    //Kode Nomor BHP
    public function no_layanan()   {

		$thn = date('ym');

		$q = $this->db->query("SELECT MAX(RIGHT(id_layanan,3)) AS kd_max FROM tb_layanan WHERE MID(id_layanan,3,4)=$thn");
        $kd = "";
        if($q->num_rows()>0){
            foreach($q->result() as $k){
                $tmp = ((int)$k->kd_max)+1;
                $kd = sprintf("%03s", $tmp);
            }
        }else{
            $kd = "001";
        }
        $kodejadi = "L-".$thn.$kd;
        return $kodejadi;
    }

    public function no_bukti()   {

		$thn = date('ym');

		$q = $this->db->query("SELECT MAX(RIGHT(FNO_BUKTI,3)) AS kd_max FROM t1_h_biaya WHERE MID(FNO_BUKTI,2,4)=$thn");
        $kd = "";
        if($q->num_rows()>0){
            foreach($q->result() as $k){
                $tmp = ((int)$k->kd_max)+1;
                $kd = sprintf("%03s", $tmp);
            }
        }else{
            $kd = "001";
        }
        $kodejadi = "L".$thn.$kd;
        return $kodejadi;
    }

	//Kode Cek Alamat Dropdown
	public function cek_address() {

		$ipaddress = '';
	    if (getenv('HTTP_CLIENT_IP'))
	        $ipaddress = getenv('HTTP_CLIENT_IP');
	    else if(getenv('HTTP_X_FORWARDED_FOR'))
	        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
	    else if(getenv('HTTP_X_FORWARDED'))
	        $ipaddress = getenv('HTTP_X_FORWARDED');
	    else if(getenv('HTTP_FORWARDED_FOR'))
	        $ipaddress = getenv('HTTP_FORWARDED_FOR');
	    else if(getenv('HTTP_FORWARDED'))
	       $ipaddress = getenv('HTTP_FORWARDED');
	    else if(getenv('REMOTE_ADDR'))
	        $ipaddress = getenv('REMOTE_ADDR');
	    else
	        $ipaddress = 'IP tidak dikenali';
	    return $ipaddress;  

	}


	
	public function insert_data($data,$table){
		$this->db->insert($table,$data);
	}

	public function update_data($table, $data, $where){
		$this->db->update($table, $data, $where);
	}

	public function delete_data($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}

	public function get_cart($table,$where){https://ipm.corel.com/static/ipm/images/products/ptr/20221005-ptr2022-x-sell-to-ptr-active-expired-tbyb-pc/ipm-launch-horiz-02.jpg
    	$this->db->get($table);
    	$this->db->where($where);

    }

	public function cek_login(){
		$username 	= set_value('username');
		$password 	= set_value('password');

		$result	= $this->db->where('username',$username)
						   ->where('password',$password)
						   ->limit(1)
						   ->get('t00_m_users');
		if($result->num_rows()>0){
		
				return $result->row();

		}else{
			return FALSE;
		}
	}
}

 ?>